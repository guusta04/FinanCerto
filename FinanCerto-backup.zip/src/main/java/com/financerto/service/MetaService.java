package com.financerto.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.AporteRequestDTO;
import com.financerto.dto.MetaRequestDTO;
import com.financerto.dto.MetaResponseDTO;
import com.financerto.model.Meta;
import com.financerto.model.Usuario;
import com.financerto.repository.MetaRepository;

@Service
public class MetaService {

    private final MetaRepository metaRepository;

    public MetaService(MetaRepository metaRepository) {
        this.metaRepository = metaRepository;
    }

    public MetaResponseDTO criar(MetaRequestDTO dados, Usuario usuarioLogado) {
        Meta meta = new Meta();
        meta.setTitulo(dados.getTitulo());
        meta.setValorAlvo(dados.getValorAlvo());
        meta.setPrazo(dados.getPrazo());
        meta.setUsuario(usuarioLogado);

        meta = metaRepository.save(meta);
        return toResponseDTO(meta);
    }

    public List<MetaResponseDTO> listar(Usuario usuarioLogado) {
        return metaRepository.findByUsuario(usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public MetaResponseDTO editar(Long id, MetaRequestDTO dados, Usuario usuarioLogado) {
        Meta meta = buscarDoUsuario(id, usuarioLogado);

        meta.setTitulo(dados.getTitulo());
        meta.setValorAlvo(dados.getValorAlvo());
        meta.setPrazo(dados.getPrazo());

        meta = metaRepository.save(meta);
        return toResponseDTO(meta);
    }

    public MetaResponseDTO aportar(Long id, AporteRequestDTO dados, Usuario usuarioLogado) {
        Meta meta = buscarDoUsuario(id, usuarioLogado);
        meta.setValorAtual(meta.getValorAtual().add(dados.getValor()));

        meta = metaRepository.save(meta);
        return toResponseDTO(meta);
    }

    public void excluir(Long id, Usuario usuarioLogado) {
        Meta meta = buscarDoUsuario(id, usuarioLogado);
        metaRepository.delete(meta);
    }

    private Meta buscarDoUsuario(Long id, Usuario usuarioLogado) {
        Meta meta = metaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Meta não encontrada"));

        if (!meta.getUsuario().getId().equals(usuarioLogado.getId())) {
            throw new IllegalArgumentException("Você não tem permissão para acessar essa meta");
        }

        return meta;
    }

    private MetaResponseDTO toResponseDTO(Meta meta) {
        double progresso = meta.getValorAtual()
                .divide(meta.getValorAlvo(), 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .doubleValue();

        progresso = Math.min(progresso, 100);
        boolean concluida = meta.getValorAtual().compareTo(meta.getValorAlvo()) >= 0;

        return new MetaResponseDTO(
                meta.getId(), meta.getTitulo(), meta.getValorAlvo(), meta.getValorAtual(),
                meta.getPrazo(), progresso, concluida
        );
    }
}
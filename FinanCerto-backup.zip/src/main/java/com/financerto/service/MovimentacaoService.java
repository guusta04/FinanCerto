package com.financerto.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.MovimentacaoRequestDTO;
import com.financerto.dto.MovimentacaoResponseDTO;
import com.financerto.dto.SaldoResponseDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Categoria;
import com.financerto.model.Movimentacao;
import com.financerto.model.Usuario;
import com.financerto.repository.CategoriaRepository;
import com.financerto.repository.MovimentacaoRepository;

@Service
public class MovimentacaoService {

    private final MovimentacaoRepository movimentacaoRepository;
    private final CategoriaRepository categoriaRepository;

    public MovimentacaoService(MovimentacaoRepository movimentacaoRepository,
                                CategoriaRepository categoriaRepository) {
        this.movimentacaoRepository = movimentacaoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    public MovimentacaoResponseDTO cadastrar(MovimentacaoRequestDTO dados, Usuario usuarioLogado) {
        Categoria categoria = categoriaRepository.findById(dados.getCategoriaId())
                .orElseThrow(() -> new IllegalArgumentException("Categoria não encontrada"));

        Movimentacao movimentacao = new Movimentacao();
        movimentacao.setDescricao(dados.getDescricao());
        movimentacao.setValor(dados.getValor());
        movimentacao.setData(dados.getData());
        movimentacao.setTipo(dados.getTipo());
        movimentacao.setCategoria(categoria);
        movimentacao.setUsuario(usuarioLogado);

        movimentacao = movimentacaoRepository.save(movimentacao);
        return toResponseDTO(movimentacao);
    }

    public List<MovimentacaoResponseDTO> listar(Usuario usuarioLogado, TipoMovimentacao tipo,
                                                 Long categoriaId, LocalDate dataInicio, LocalDate dataFim) {
        return movimentacaoRepository.filtrar(usuarioLogado, tipo, categoriaId, dataInicio, dataFim).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public MovimentacaoResponseDTO editar(Long id, MovimentacaoRequestDTO dados, Usuario usuarioLogado) {
        Movimentacao movimentacao = buscarDoUsuario(id, usuarioLogado);

        Categoria categoria = categoriaRepository.findById(dados.getCategoriaId())
                .orElseThrow(() -> new IllegalArgumentException("Categoria não encontrada"));

        movimentacao.setDescricao(dados.getDescricao());
        movimentacao.setValor(dados.getValor());
        movimentacao.setData(dados.getData());
        movimentacao.setTipo(dados.getTipo());
        movimentacao.setCategoria(categoria);

        movimentacao = movimentacaoRepository.save(movimentacao);
        return toResponseDTO(movimentacao);
    }

    public void excluir(Long id, Usuario usuarioLogado) {
        Movimentacao movimentacao = buscarDoUsuario(id, usuarioLogado);
        movimentacaoRepository.delete(movimentacao);
    }

    public SaldoResponseDTO calcularSaldo(Usuario usuarioLogado) {
        BigDecimal totalReceitas = movimentacaoRepository.somarPorTipo(usuarioLogado, TipoMovimentacao.RECEITA);
        BigDecimal totalDespesas = movimentacaoRepository.somarPorTipo(usuarioLogado, TipoMovimentacao.DESPESA);
        BigDecimal saldo = totalReceitas.subtract(totalDespesas);
        return new SaldoResponseDTO(totalReceitas, totalDespesas, saldo);
    }

    private Movimentacao buscarDoUsuario(Long id, Usuario usuarioLogado) {
        Movimentacao movimentacao = movimentacaoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Movimentação não encontrada"));

        if (!movimentacao.getUsuario().getId().equals(usuarioLogado.getId())) {
            throw new IllegalArgumentException("Você não tem permissão para acessar essa movimentação");
        }

        return movimentacao;
    }

    private MovimentacaoResponseDTO toResponseDTO(Movimentacao movimentacao) {
        return new MovimentacaoResponseDTO(
                movimentacao.getId(),
                movimentacao.getDescricao(),
                movimentacao.getValor(),
                movimentacao.getData(),
                movimentacao.getTipo(),
                movimentacao.getCategoria().getNome()
        );
    }
}

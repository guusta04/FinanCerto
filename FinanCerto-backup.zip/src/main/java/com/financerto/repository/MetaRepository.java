package com.financerto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.financerto.model.Meta;
import com.financerto.model.Usuario;

public interface MetaRepository extends JpaRepository<Meta, Long> {
    List<Meta> findByUsuario(Usuario usuario);
}
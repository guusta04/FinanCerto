package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MetaResponseDTO {

    private Long id;
    private String titulo;
    private BigDecimal valorAlvo;
    private BigDecimal valorAtual;
    private LocalDate prazo;
    private double progresso; // percentual, 0 a 100
    private boolean concluida;

    public MetaResponseDTO(Long id, String titulo, BigDecimal valorAlvo, BigDecimal valorAtual,
                            LocalDate prazo, double progresso, boolean concluida) {
        this.id = id;
        this.titulo = titulo;
        this.valorAlvo = valorAlvo;
        this.valorAtual = valorAtual;
        this.prazo = prazo;
        this.progresso = progresso;
        this.concluida = concluida;
    }

    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public BigDecimal getValorAlvo() { return valorAlvo; }
    public BigDecimal getValorAtual() { return valorAtual; }
    public LocalDate getPrazo() { return prazo; }
    public double getProgresso() { return progresso; }
    public boolean isConcluida() { return concluida; }
}

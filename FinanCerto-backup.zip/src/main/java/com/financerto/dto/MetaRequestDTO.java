package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class MetaRequestDTO {

    @NotBlank(message = "O título da meta é obrigatório")
    private String titulo;

    @NotNull(message = "O valor desejado é obrigatório")
    @DecimalMin(value = "0.01", message = "O valor desejado deve ser maior que zero")
    private BigDecimal valorAlvo;

    @NotNull(message = "O prazo é obrigatório")
    @FutureOrPresent(message = "O prazo não pode ser uma data passada")
    private LocalDate prazo;

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public BigDecimal getValorAlvo() { return valorAlvo; }
    public void setValorAlvo(BigDecimal valorAlvo) { this.valorAlvo = valorAlvo; }
    public LocalDate getPrazo() { return prazo; }
    public void setPrazo(LocalDate prazo) { this.prazo = prazo; }
}

package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.AporteRequestDTO;
import com.financerto.dto.MetaRequestDTO;
import com.financerto.dto.MetaResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.MetaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/metas")
public class MetaController {

    private final MetaService metaService;

    public MetaController(MetaService metaService) {
        this.metaService = metaService;
    }

    @PostMapping
    public ResponseEntity<MetaResponseDTO> criar(@Valid @RequestBody MetaRequestDTO dados,
                                                  @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaService.criar(dados, usuarioLogado));
    }

    @GetMapping
    public ResponseEntity<List<MetaResponseDTO>> listar(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaService.listar(usuarioLogado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MetaResponseDTO> editar(@PathVariable Long id,
                                                   @Valid @RequestBody MetaRequestDTO dados,
                                                   @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaService.editar(id, dados, usuarioLogado));
    }

    @PostMapping("/{id}/aportes")
    public ResponseEntity<MetaResponseDTO> aportar(@PathVariable Long id,
                                                    @Valid @RequestBody AporteRequestDTO dados,
                                                    @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaService.aportar(id, dados, usuarioLogado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id, @AuthenticationPrincipal Usuario usuarioLogado) {
        metaService.excluir(id, usuarioLogado);
        return ResponseEntity.noContent().build();
    }
}

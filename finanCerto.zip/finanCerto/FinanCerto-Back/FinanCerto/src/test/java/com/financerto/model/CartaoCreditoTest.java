package com.financerto.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class CartaoCreditoTest {

    private CartaoCredito cartao;
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João Silva");

        cartao = new CartaoCredito(
            usuario,
            "4111111111111111",
            "Visa Débito",
            new BigDecimal("5000.00"),
            LocalDate.of(2028, 12, 31),
            CartaoCredito.BandeiraCartao.VISA,
            15
        );
    }

    @Test
    void testCriarCartao() {
        assertNotNull(cartao);
        assertEquals("Visa Débito", cartao.getNomeCartao());
        assertEquals(new BigDecimal("5000.00"), cartao.getLimiteCartao());
        assertEquals(CartaoCredito.StatusCartao.ATIVO, cartao.getStatus());
    }

    @Test
    void testCalcularPercentualUso() {
        cartao.setSaldoDisponivel(new BigDecimal("2500.00"));
        BigDecimal percentual = cartao.getPercentualUso();
        assertEquals(new BigDecimal("50.00"), percentual);
    }

    @Test
    void testSaldoUsado() {
        cartao.setSaldoDisponivel(new BigDecimal("3000.00"));
        BigDecimal usado = cartao.getSaldoUsado();
        assertEquals(new BigDecimal("2000.00"), usado);
    }

    @Test
    void testBloqueioCartao() {
        cartao.setStatus(CartaoCredito.StatusCartao.BLOQUEADO);
        assertEquals(CartaoCredito.StatusCartao.BLOQUEADO, cartao.getStatus());
    }
}


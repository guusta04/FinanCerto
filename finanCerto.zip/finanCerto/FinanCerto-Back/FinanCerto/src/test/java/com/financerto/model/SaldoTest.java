package com.financerto.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class SaldoTest {

    private Saldo saldo;
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João Silva");

        saldo = new Saldo(usuario);
    }

    @Test
    void testCriarSaldo() {
        assertNotNull(saldo);
        assertEquals(BigDecimal.ZERO, saldo.getSaldoAtual());
        assertEquals(BigDecimal.ZERO, saldo.getTotalReceitas());
        assertEquals(BigDecimal.ZERO, saldo.getTotalDespesas());
    }

    @Test
    void testAtualizarSaldo() {
        saldo.setTotalReceitas(new BigDecimal("1000.00"));
        saldo.setTotalDespesas(new BigDecimal("300.00"));
        saldo.setSaldoAtual(new BigDecimal("700.00"));

        assertEquals(new BigDecimal("1000.00"), saldo.getTotalReceitas());
        assertEquals(new BigDecimal("300.00"), saldo.getTotalDespesas());
        assertEquals(new BigDecimal("700.00"), saldo.getSaldoAtual());
    }
}


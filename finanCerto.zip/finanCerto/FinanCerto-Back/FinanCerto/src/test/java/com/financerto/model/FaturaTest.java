package com.financerto.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FaturaTest {

    private Fatura fatura;
    private CartaoCredito cartao;
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João Silva");

        cartao = new CartaoCredito(
            usuario,
            "4111111111111111",
            "Visa",
            new BigDecimal("5000.00"),
            LocalDate.of(2028, 12, 31),
            CartaoCredito.BandeiraCartao.VISA,
            15
        );

        fatura = new Fatura(
            cartao,
            LocalDate.now(),
            LocalDate.now().plusDays(10)
        );
    }

    @Test
    void testCriarFatura() {
        assertNotNull(fatura);
        assertEquals(Fatura.StatusFatura.ABERTA, fatura.getStatus());
    }

    @Test
    void testCalcularValorPendente() {
        fatura.setValorTotal(new BigDecimal("1000.00"));
        fatura.setValorPago(new BigDecimal("600.00"));
        
        BigDecimal pendente = fatura.getValorPendente();
        assertEquals(new BigDecimal("400.00"), pendente);
    }

        @Test
    void testFaturaPaga() {
        fatura.setValorTotal(new BigDecimal("1000.00"));
        fatura.setValorPago(new BigDecimal("1000.00"));
        fatura.setStatus(Fatura.StatusFatura.PAGA);
        
        assertEquals(Fatura.StatusFatura.PAGA, fatura.getStatus());
        assertEquals(0, fatura.getValorPendente().compareTo(BigDecimal.ZERO));

    }

}



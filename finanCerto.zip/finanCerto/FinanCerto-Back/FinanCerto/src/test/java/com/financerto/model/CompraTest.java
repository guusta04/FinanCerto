package com.financerto.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class CompraTest {

    private Compra compra;
    private Usuario usuario;
    private CartaoCredito cartao;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João Silva");

        cartao = new CartaoCredito(
            usuario,
            "4111111111111111",
            "Visa",
            new BigDecimal("5000.00"),
            LocalDate.of(2028, 12, 31),
            CartaoCredito.BandeiraCartao.VISA,
            15
        );

        compra = new Compra(
            usuario,
            cartao,
            "Compra eletrônicos",
            new BigDecimal("1200.00"),
            LocalDate.now()
        );
        compra.setParcelasTotal(3);
    }

    @Test
    void testCriarCompra() {
        assertNotNull(compra);
        assertEquals("Compra eletrônicos", compra.getDescricao());
        assertEquals(new BigDecimal("1200.00"), compra.getValor());
        assertEquals(Compra.StatusCompra.PENDENTE, compra.getStatus());
    }

    @Test
    void testCalcularValorParcela() {
        compra.setParcelasTotal(3);
        BigDecimal valorParcela = compra.getValorParcela();
        assertEquals(new BigDecimal("400.00"), valorParcela);
    }

    @Test
    void testCompraAVista() {
        compra.setParcelasTotal(1);
        BigDecimal valorParcela = compra.getValorParcela();
        assertEquals(new BigDecimal("1200.00"), valorParcela);
    }
}


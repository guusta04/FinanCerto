package com.financerto.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MetaFinanceiraTest {

    private MetaFinanceira metaFinanceira;
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João Silva");
        usuario.setEmail("joao@example.com");

        metaFinanceira = new MetaFinanceira(
            usuario,
            "Economizar para férias",
            new BigDecimal("5000.00"),
            LocalDate.of(2026, 12, 31)
        );
    }

    @Test
    void testCriarMetaFinanceira() {
        assertNotNull(metaFinanceira);
        assertEquals("Economizar para férias", metaFinanceira.getDescricao());
        assertEquals(new BigDecimal("5000.00"), metaFinanceira.getValorMeta());
        assertEquals(MetaFinanceira.StatusMetaFinanceira.ATIVA, metaFinanceira.getStatus());
    }

    @Test
    void testCalcularPercentualProgresso() {
        metaFinanceira.setValorAtual(new BigDecimal("2500.00"));
        BigDecimal percentual = metaFinanceira.getPercentualProgresso();
        assertEquals(new BigDecimal("50.00"), percentual);
    }

   @Test
void testPercentualProgressoZero() {
    metaFinanceira.setValorAtual(BigDecimal.ZERO);
    BigDecimal percentual = metaFinanceira.getPercentualProgresso();
    assertEquals(0, percentual.compareTo(BigDecimal.ZERO));

}

    @Test
    void testPercentualProgressoCem() {
        metaFinanceira.setValorAtual(new BigDecimal("5000.00"));
        BigDecimal percentual = metaFinanceira.getPercentualProgresso();
        assertEquals(new BigDecimal("100.00"), percentual);
    }

    @Test
    void testAlterarStatus() {
        metaFinanceira.setStatus(MetaFinanceira.StatusMetaFinanceira.CONCLUIDA);
        assertEquals(MetaFinanceira.StatusMetaFinanceira.CONCLUIDA, metaFinanceira.getStatus());
    }
}


package com.financerto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancertoApplicationTests {

	@Test
	void contextLoads() {
		// Teste de contexto será habilitado após completar a implementação
	}
}



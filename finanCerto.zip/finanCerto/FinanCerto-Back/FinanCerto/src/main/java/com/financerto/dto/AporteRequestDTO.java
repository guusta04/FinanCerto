package com.financerto.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public class AporteRequestDTO {

    @NotNull(message = "O valor do aporte é obrigatório")
    @DecimalMin(value = "0.01", message = "O valor do aporte deve ser maior que zero")
    private BigDecimal valor;

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
}

package com.financerto.service;

import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Saldo;
import com.financerto.model.Usuario;
import com.financerto.repository.MovimentacaoRepository;
import com.financerto.repository.SaldoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class SaldoService {

    private final SaldoRepository saldoRepository;
    private final MovimentacaoRepository movimentacaoRepository;

    public SaldoService(SaldoRepository saldoRepository, MovimentacaoRepository movimentacaoRepository) {
        this.saldoRepository = saldoRepository;
        this.movimentacaoRepository = movimentacaoRepository;
    }

    public Saldo obterOuCriar(Usuario usuario) {
        return saldoRepository.findByUsuario(usuario)
                .orElseGet(() -> saldoRepository.save(new Saldo(usuario)));
    }

    public Saldo recalcular(Usuario usuario) {
        Saldo saldo = obterOuCriar(usuario);

        var totalReceitas = movimentacaoRepository.somarPorTipo(usuario, TipoMovimentacao.RECEITA);
        var totalDespesas = movimentacaoRepository.somarPorTipo(usuario, TipoMovimentacao.DESPESA);

        saldo.setTotalReceitas(totalReceitas);
        saldo.setTotalDespesas(totalDespesas);
        saldo.setSaldoAtual(totalReceitas.subtract(totalDespesas));
        saldo.setDataAtualizacao(LocalDateTime.now());

        return saldoRepository.save(saldo);
    }
}
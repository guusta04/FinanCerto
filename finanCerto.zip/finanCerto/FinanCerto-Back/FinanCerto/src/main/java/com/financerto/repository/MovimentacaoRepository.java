package com.financerto.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Movimentacao;
import com.financerto.model.Usuario;

public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Long> {

    @Query("""
            SELECT m FROM Movimentacao m
            WHERE m.usuario = :usuario
            AND (:tipo IS NULL OR m.tipo = :tipo)
            AND (:categoriaId IS NULL OR m.categoria.id = :categoriaId)
            AND (:dataInicio IS NULL OR m.data >= :dataInicio)
            AND (:dataFim IS NULL OR m.data <= :dataFim)
            ORDER BY m.data DESC
            """)
    List<Movimentacao> filtrar(@Param("usuario") Usuario usuario,
                                @Param("tipo") TipoMovimentacao tipo,
                                @Param("categoriaId") Long categoriaId,
                                @Param("dataInicio") LocalDate dataInicio,
                                @Param("dataFim") LocalDate dataFim);

    @Query("SELECT COALESCE(SUM(m.valor), 0) FROM Movimentacao m WHERE m.usuario = :usuario AND m.tipo = :tipo")
    BigDecimal somarPorTipo(@Param("usuario") Usuario usuario, @Param("tipo") TipoMovimentacao tipo);
}
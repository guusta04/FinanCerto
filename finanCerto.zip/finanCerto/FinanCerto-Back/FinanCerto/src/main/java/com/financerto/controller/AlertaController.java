package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.AlertaResponseDTO;
import com.financerto.model.Alerta;
import com.financerto.model.Usuario;
import com.financerto.service.AlertaService;

@RestController
@RequestMapping("/alertas")
public class AlertaController {

    private final AlertaService alertaService;

    public AlertaController(AlertaService alertaService) {
        this.alertaService = alertaService;
    }

    @GetMapping
    public ResponseEntity<List<AlertaResponseDTO>> listar(@AuthenticationPrincipal Usuario usuarioLogado) {
        List<AlertaResponseDTO> alertas = alertaService.listar(usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();

        return ResponseEntity.ok(alertas);
    }

    @PatchMapping("/{id}/lido")
    public ResponseEntity<AlertaResponseDTO> marcarComoLido(@PathVariable Long id,
                                                             @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(toResponseDTO(alertaService.marcarComoLido(id, usuarioLogado)));
    }

    private AlertaResponseDTO toResponseDTO(Alerta alerta) {
        return new AlertaResponseDTO(
                alerta.getId(),
                alerta.getUsuario().getId(),
                alerta.getTitulo(),
                alerta.getMensagem(),
                alerta.getTipo().name(),
                alerta.getLimiteGasto(),
                alerta.getGastoAtual(),
                alerta.getDataCriacao(),
                alerta.getLido()
        );
    }
}

package com.financerto.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.model.Alerta;
import com.financerto.model.Usuario;
import com.financerto.repository.AlertaRepository;

@Service
public class AlertaService {

    private final AlertaRepository alertaRepository;

    public AlertaService(AlertaRepository alertaRepository) {
        this.alertaRepository = alertaRepository;
    }

    public void criar(Usuario usuario, String titulo, String mensagem, Alerta.TipoAlerta tipo,
                       BigDecimal limiteGasto, BigDecimal gastoAtual) {
        Alerta alerta = new Alerta(usuario, titulo, mensagem, tipo, limiteGasto, gastoAtual);
        alertaRepository.save(alerta);
    }

    public List<Alerta> listar(Usuario usuarioLogado) {
        return alertaRepository.findByUsuario(usuarioLogado);
    }

    public Alerta marcarComoLido(Long id, Usuario usuarioLogado) {
        Alerta alerta = alertaRepository.findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Alerta nao encontrado"));

        alerta.setLido(true);

        return alertaRepository.save(alerta);
    }
}

package com.financerto.dto;

import com.financerto.enums.Role;

import jakarta.validation.constraints.NotNull;

public class AlterarRoleRequestDTO {

    @NotNull(message = "O papel (role) é obrigatório")
    private Role role;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}

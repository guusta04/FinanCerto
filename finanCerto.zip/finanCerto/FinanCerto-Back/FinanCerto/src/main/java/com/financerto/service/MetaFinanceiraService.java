package com.financerto.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.AporteRequestDTO;
import com.financerto.dto.MetaFinanceiraRequestDTO;
import com.financerto.dto.MetaFinanceiraResponseDTO;
import com.financerto.model.MetaFinanceira;
import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;
import com.financerto.repository.MetaFinanceiraRepository;

@Service
public class MetaFinanceiraService {

    private final MetaFinanceiraRepository metaFinanceiraRepository;
    private final NotificacaoService notificacaoService;

    public MetaFinanceiraService(MetaFinanceiraRepository metaFinanceiraRepository,
                                  NotificacaoService notificacaoService) {
        this.metaFinanceiraRepository = metaFinanceiraRepository;
        this.notificacaoService = notificacaoService;
    }

    public MetaFinanceiraResponseDTO criar(MetaFinanceiraRequestDTO dados, Usuario usuarioLogado) {
        MetaFinanceira meta = new MetaFinanceira(usuarioLogado, dados.getDescricao(), dados.getValorMeta(), dados.getDataMeta());
        meta = metaFinanceiraRepository.save(meta);

        notificacaoService.criar(usuarioLogado, "Meta criada",
                "Voce criou a meta \"" + meta.getDescricao() + "\" no valor de R$ " + meta.getValorMeta(),
                Notificacao.TipoNotificacao.META_CRIADA);

        return toResponseDTO(meta);
    }

    public List<MetaFinanceiraResponseDTO> listar(Usuario usuarioLogado) {
        return metaFinanceiraRepository.findByUsuario(usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public MetaFinanceiraResponseDTO editar(Long id, MetaFinanceiraRequestDTO dados, Usuario usuarioLogado) {
        MetaFinanceira meta = buscarDoUsuario(id, usuarioLogado);

        meta.setDescricao(dados.getDescricao());
        meta.setValorMeta(dados.getValorMeta());
        meta.setDataMeta(dados.getDataMeta());

        meta = metaFinanceiraRepository.save(meta);
        return toResponseDTO(meta);
    }

    public MetaFinanceiraResponseDTO aportar(Long id, AporteRequestDTO dados, Usuario usuarioLogado) {
        MetaFinanceira meta = buscarDoUsuario(id, usuarioLogado);

        boolean jaEstavaConcluida = meta.getStatus() == MetaFinanceira.StatusMetaFinanceira.CONCLUIDA;

        meta.setValorAtual(meta.getValorAtual().add(dados.getValor()));

        if (meta.getValorAtual().compareTo(meta.getValorMeta()) >= 0) {
            meta.setStatus(MetaFinanceira.StatusMetaFinanceira.CONCLUIDA);
        }

        meta = metaFinanceiraRepository.save(meta);

        if (!jaEstavaConcluida && meta.getStatus() == MetaFinanceira.StatusMetaFinanceira.CONCLUIDA) {
            notificacaoService.criar(usuarioLogado, "Meta atingida",
                    "Parabens! Voce atingiu a meta \"" + meta.getDescricao() + "\"",
                    Notificacao.TipoNotificacao.META_ATINGIDA);
        }

        return toResponseDTO(meta);
    }

    public MetaFinanceiraResponseDTO cancelar(Long id, Usuario usuarioLogado) {
        MetaFinanceira meta = buscarDoUsuario(id, usuarioLogado);
        meta.setStatus(MetaFinanceira.StatusMetaFinanceira.CANCELADA);
        meta = metaFinanceiraRepository.save(meta);
        return toResponseDTO(meta);
    }

    public void excluir(Long id, Usuario usuarioLogado) {
        MetaFinanceira meta = buscarDoUsuario(id, usuarioLogado);
        metaFinanceiraRepository.delete(meta);
    }

    private MetaFinanceira buscarDoUsuario(Long id, Usuario usuarioLogado) {
        return metaFinanceiraRepository.findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Meta não encontrada"));
    }

    private MetaFinanceiraResponseDTO toResponseDTO(MetaFinanceira meta) {
        return new MetaFinanceiraResponseDTO(
                meta.getId(),
                meta.getUsuario().getId(),
                meta.getDescricao(),
                meta.getValorMeta(),
                meta.getValorAtual(),
                meta.getDataMeta(),
                meta.getDataCriacao(),
                meta.getStatus().name(),
                meta.getPercentualProgresso()
        );
    }
}
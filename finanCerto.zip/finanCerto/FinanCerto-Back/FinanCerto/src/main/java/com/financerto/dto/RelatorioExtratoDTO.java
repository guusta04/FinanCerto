package com.financerto.dto;
 
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
 
public class RelatorioExtratoDTO {
 
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private BigDecimal totalReceitas;
    private BigDecimal totalDespesas;
    private BigDecimal saldoPeriodo;
    private List<MovimentacaoResponseDTO> movimentacoes;
 
    public RelatorioExtratoDTO(LocalDate dataInicio, LocalDate dataFim, BigDecimal totalReceitas,
                                BigDecimal totalDespesas, BigDecimal saldoPeriodo,
                                List<MovimentacaoResponseDTO> movimentacoes) {
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.totalReceitas = totalReceitas;
        this.totalDespesas = totalDespesas;
        this.saldoPeriodo = saldoPeriodo;
        this.movimentacoes = movimentacoes;
    }
 
    public LocalDate getDataInicio() { return dataInicio; }
    public LocalDate getDataFim() { return dataFim; }
    public BigDecimal getTotalReceitas() { return totalReceitas; }
    public BigDecimal getTotalDespesas() { return totalDespesas; }
    public BigDecimal getSaldoPeriodo() { return saldoPeriodo; }
    public List<MovimentacaoResponseDTO> getMovimentacoes() { return movimentacoes; }
}
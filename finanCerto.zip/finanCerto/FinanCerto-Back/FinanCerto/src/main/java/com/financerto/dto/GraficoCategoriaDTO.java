package com.financerto.dto;

import java.math.BigDecimal;

public class GraficoCategoriaDTO {
    private String categoria;
    private BigDecimal total;

    public GraficoCategoriaDTO(String categoria, BigDecimal total) {
        this.categoria = categoria;
        this.total = total;
    }

    public String getCategoria() { return categoria; }
    public BigDecimal getTotal() { return total; }
}

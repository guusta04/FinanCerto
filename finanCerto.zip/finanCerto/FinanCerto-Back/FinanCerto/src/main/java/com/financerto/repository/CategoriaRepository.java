package com.financerto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.financerto.model.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}

package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FaturaResponseDTO {

    private Long id;
    private Long cartaoId;
    private LocalDate dataFatura;
    private LocalDate dataVencimento;
    private BigDecimal valorTotal;
    private BigDecimal valorPago;
    private BigDecimal valorPendente;
    private String status;

    // Construtores
    public FaturaResponseDTO() {}

    public FaturaResponseDTO(Long id, Long cartaoId, LocalDate dataFatura,
                            LocalDate dataVencimento, BigDecimal valorTotal,
                            BigDecimal valorPago, BigDecimal valorPendente,
                            String status) {
        this.id = id;
        this.cartaoId = cartaoId;
        this.dataFatura = dataFatura;
        this.dataVencimento = dataVencimento;
        this.valorTotal = valorTotal;
        this.valorPago = valorPago;
        this.valorPendente = valorPendente;
        this.status = status;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCartaoId() {
        return cartaoId;
    }

    public void setCartaoId(Long cartaoId) {
        this.cartaoId = cartaoId;
    }

    public LocalDate getDataFatura() {
        return dataFatura;
    }

    public void setDataFatura(LocalDate dataFatura) {
        this.dataFatura = dataFatura;
    }

    public LocalDate getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(LocalDate dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public BigDecimal getValorPago() {
        return valorPago;
    }

    public void setValorPago(BigDecimal valorPago) {
        this.valorPago = valorPago;
    }

    public BigDecimal getValorPendente() {
        return valorPendente;
    }

    public void setValorPendente(BigDecimal valorPendente) {
        this.valorPendente = valorPendente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}


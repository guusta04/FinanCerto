package com.financerto.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.CartaoCredito;
import com.financerto.model.Compra;
import com.financerto.model.Usuario;

@Repository
public interface CompraRepository extends JpaRepository<Compra, Long> {

    List<Compra> findByUsuario(Usuario usuario);

    List<Compra> findByUsuarioId(Long usuarioId);

    List<Compra> findByCartaoCredito(CartaoCredito cartaoCredito);

    List<Compra> findByCartaoCredito_Id(Long cartaoId);

    List<Compra> findByDataCompraBetween(
            LocalDate dataInicio,
            LocalDate dataFim
    );

    List<Compra> findByUsuarioIdAndDataCompraBetween(
            Long usuarioId,
            LocalDate dataInicio,
            LocalDate dataFim
    );

    List<Compra> findByStatus(Compra.StatusCompra status);

    List<Compra> findByUsuarioIdAndStatus(
            Long usuarioId,
            Compra.StatusCompra status
    );

    Optional<Compra> findByIdAndUsuarioId(
            Long id,
            Long usuarioId
    );

    List<Compra> findByCartaoCredito_IdAndDataCompraBetween(
            Long cartaoId,
            LocalDate dataInicio,
            LocalDate dataFim
    );
}
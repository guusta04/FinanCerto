package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.AporteRequestDTO;
import com.financerto.dto.MetaFinanceiraRequestDTO;
import com.financerto.dto.MetaFinanceiraResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.MetaFinanceiraService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/metas")
public class MetaFinanceiraController {

    private final MetaFinanceiraService metaFinanceiraService;

    public MetaFinanceiraController(MetaFinanceiraService metaFinanceiraService) {
        this.metaFinanceiraService = metaFinanceiraService;
    }

    @PostMapping
    public ResponseEntity<MetaFinanceiraResponseDTO> criar(@Valid @RequestBody MetaFinanceiraRequestDTO dados,
                                                             @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaFinanceiraService.criar(dados, usuarioLogado));
    }

    @GetMapping
    public ResponseEntity<List<MetaFinanceiraResponseDTO>> listar(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaFinanceiraService.listar(usuarioLogado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MetaFinanceiraResponseDTO> editar(@PathVariable Long id,
                                                             @Valid @RequestBody MetaFinanceiraRequestDTO dados,
                                                             @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaFinanceiraService.editar(id, dados, usuarioLogado));
    }

    @PostMapping("/{id}/aportes")
    public ResponseEntity<MetaFinanceiraResponseDTO> aportar(@PathVariable Long id,
                                                              @Valid @RequestBody AporteRequestDTO dados,
                                                              @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaFinanceiraService.aportar(id, dados, usuarioLogado));
    }

    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<MetaFinanceiraResponseDTO> cancelar(@PathVariable Long id,
                                                               @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(metaFinanceiraService.cancelar(id, usuarioLogado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id, @AuthenticationPrincipal Usuario usuarioLogado) {
        metaFinanceiraService.excluir(id, usuarioLogado);
        return ResponseEntity.noContent().build();
    }
}

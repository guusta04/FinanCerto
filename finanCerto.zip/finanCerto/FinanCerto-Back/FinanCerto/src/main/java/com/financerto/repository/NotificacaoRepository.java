package com.financerto.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;

@Repository
public interface NotificacaoRepository extends JpaRepository<Notificacao, Long> {
    
    List<Notificacao> findByUsuario(Usuario usuario);
    
    List<Notificacao> findByUsuarioId(Long usuarioId);
    
    List<Notificacao> findByUsuarioAndLida(Usuario usuario, Boolean lida);
    
    List<Notificacao> findByUsuarioIdAndLida(Long usuarioId, Boolean lida);
    
    List<Notificacao> findByTipo(Notificacao.TipoNotificacao tipo);
    
    List<Notificacao> findByUsuarioIdAndTipo(Long usuarioId, Notificacao.TipoNotificacao tipo);
    
    List<Notificacao> findByDataCriacao(LocalDateTime data);
    
    List<Notificacao> findByDataCriacao(LocalDateTime dataInicio, LocalDateTime dataFim);
    
    List<Notificacao> findByUsuarioIdAndDataCriacaoBetween(Long usuarioId, 
            LocalDateTime dataInicio, LocalDateTime dataFim);
    
    Optional<Notificacao> findByIdAndUsuarioId(Long id, Long usuarioId);
    
    Long countByUsuarioIdAndLida(Long usuarioId, Boolean lida);
    
    List<Notificacao> findByUsuarioIdOrderByDataCriacaoDesc(Long usuarioId);
}


package com.financerto.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cartao_credito")
public class CartaoCredito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @Column(nullable = false)
    private String numeroCartao;

    @Column(nullable = false)
    private String nomeCartao;

    @Column(nullable = false)
    private BigDecimal limiteCartao;

    @Column(nullable = false)
    private BigDecimal saldoDisponivel;

    @Column(nullable = false)
    private LocalDate dataValidade;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BandeiraCartao bandeira;

    @Column(nullable = false)
    private Integer diaVencimento = 1;

    @Column(nullable = false)
    private LocalDate dataCriacao = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusCartao status = StatusCartao.ATIVO;

    // Construtores
    public CartaoCredito() {}

    public CartaoCredito(Usuario usuario, String numeroCartao, String nomeCartao, 
                  BigDecimal limiteCartao, LocalDate dataValidade, 
                  BandeiraCartao bandeira, Integer diaVencimento) {
        this.usuario = usuario;
        this.numeroCartao = numeroCartao;
        this.nomeCartao = nomeCartao;
        this.limiteCartao = limiteCartao;
        this.saldoDisponivel = limiteCartao;
        this.dataValidade = dataValidade;
        this.bandeira = bandeira;
        this.diaVencimento = diaVencimento;
        this.status = StatusCartao.ATIVO;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public String getNomeCartao() {
        return nomeCartao;
    }

    public void setNomeCartao(String nomeCartao) {
        this.nomeCartao = nomeCartao;
    }

    public BigDecimal getLimiteCartao() {
        return limiteCartao;
    }

    public void setLimiteCartao(BigDecimal limiteCartao) {
        this.limiteCartao = limiteCartao;
    }

    public BigDecimal getSaldoDisponivel() {
        return saldoDisponivel;
    }

    public void setSaldoDisponivel(BigDecimal saldoDisponivel) {
        this.saldoDisponivel = saldoDisponivel;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public BandeiraCartao getBandeira() {
        return bandeira;
    }

    public void setBandeira(BandeiraCartao bandeira) {
        this.bandeira = bandeira;
    }

    public Integer getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(Integer diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public StatusCartao getStatus() {
        return status;
    }

    public void setStatus(StatusCartao status) {
        this.status = status;
    }

    // Enums
    public enum BandeiraCartao {
        VISA, MASTERCARD, ELO, AMEX
    }

    public enum StatusCartao {
        ATIVO, BLOQUEADO, CANCELADO
    }

    // Método auxiliar para calcular percentual de uso
    public BigDecimal getPercentualUso() {
        if (limiteCartao.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        BigDecimal usado = limiteCartao.subtract(saldoDisponivel);
        return usado.multiply(new BigDecimal("100"))
                .divide(limiteCartao, 2, java.math.RoundingMode.HALF_UP);
    }

    // Método auxiliar para saldo usado
    public BigDecimal getSaldoUsado() {
        return limiteCartao.subtract(saldoDisponivel);
    }
}


package com.financerto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.SaldoFinanceiroResponseDTO;
import com.financerto.model.Saldo;
import com.financerto.model.Usuario;
import com.financerto.service.SaldoService;

@RestController
@RequestMapping("/saldo")
public class SaldoController {

    private final SaldoService saldoService;

    public SaldoController(SaldoService saldoService) {
        this.saldoService = saldoService;
    }

    @GetMapping
    public ResponseEntity<SaldoFinanceiroResponseDTO> consultar(@AuthenticationPrincipal Usuario usuarioLogado) {
        Saldo saldo = saldoService.obterOuCriar(usuarioLogado);

        return ResponseEntity.ok(new SaldoFinanceiroResponseDTO(
                saldo.getId(),
                saldo.getUsuario().getId(),
                saldo.getSaldoAtual(),
                saldo.getTotalReceitas(),
                saldo.getTotalDespesas(),
                saldo.getDataAtualizacao()
        ));
    }
}   
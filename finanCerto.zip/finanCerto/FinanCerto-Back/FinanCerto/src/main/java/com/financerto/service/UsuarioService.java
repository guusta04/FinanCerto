package com.financerto.service;

import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.financerto.dto.AlterarSenhaRequestDTO;
import com.financerto.dto.AtualizarPerfilRequestDTO;
import com.financerto.dto.CadastroUsuarioDTO;
import com.financerto.dto.PerfilResponseDTO;
import com.financerto.enums.Role;
import com.financerto.model.Usuario;
import com.financerto.repository.UsuarioRepository;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Usuario cadastrar(CadastroUsuarioDTO dados) {
        if (usuarioRepository.findByEmail(dados.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Ja existe um usuario cadastrado com esse e-mail");
        }

        Usuario usuario = new Usuario();
        usuario.setNome(dados.getNome());
        usuario.setEmail(dados.getEmail());
        usuario.setSenha(passwordEncoder.encode(dados.getSenha()));

        return usuarioRepository.save(usuario);
    }

    public PerfilResponseDTO buscarPerfil(Usuario usuarioLogado) {
        return toPerfilResponseDTO(usuarioLogado);
    }

    public PerfilResponseDTO atualizarPerfil(Usuario usuarioLogado, AtualizarPerfilRequestDTO dados) {
        usuarioRepository.findByEmail(dados.getEmail()).ifPresent(outro -> {
            if (!outro.getId().equals(usuarioLogado.getId())) {
                throw new IllegalArgumentException("Ja existe um usuario cadastrado com esse e-mail");
            }
        });

        usuarioLogado.setNome(dados.getNome());
        usuarioLogado.setEmail(dados.getEmail());

        Usuario atualizado = usuarioRepository.save(usuarioLogado);
        return toPerfilResponseDTO(atualizado);
    }

    public void alterarSenha(Usuario usuarioLogado, AlterarSenhaRequestDTO dados) {
        if (!passwordEncoder.matches(dados.getSenhaAtual(), usuarioLogado.getSenha())) {
            throw new IllegalArgumentException("Senha atual incorreta");
        }

        usuarioLogado.setSenha(passwordEncoder.encode(dados.getNovaSenha()));
        usuarioRepository.save(usuarioLogado);
    }

    public List<PerfilResponseDTO> listarTodos() {
        return usuarioRepository.findAll().stream()
                .map(this::toPerfilResponseDTO)
                .toList();
    }

    public PerfilResponseDTO alterarRole(Long id, Role novaRole) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado"));

        usuario.setRole(novaRole);

        return toPerfilResponseDTO(usuarioRepository.save(usuario));
    }

    public void excluir(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuário não encontrado");
        }

        usuarioRepository.deleteById(id);
    }

    private PerfilResponseDTO toPerfilResponseDTO(Usuario usuario) {
        return new PerfilResponseDTO(
                usuario.getId(),
                usuario.getNome(),
                usuario.getEmail(),
                usuario.getRole().name()
        );
    }
}
package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SaldoFinanceiroResponseDTO {

    private Long id;
    private Long usuarioId;
    private BigDecimal saldoAtual;
    private BigDecimal totalReceitas;
    private BigDecimal totalDespesas;
    private LocalDateTime dataAtualizacao;

    // Construtores
    public SaldoFinanceiroResponseDTO() {}

    public SaldoFinanceiroResponseDTO(Long id, Long usuarioId, BigDecimal saldoAtual,
                            BigDecimal totalReceitas, BigDecimal totalDespesas,
                            LocalDateTime dataAtualizacao) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.saldoAtual = saldoAtual;
        this.totalReceitas = totalReceitas;
        this.totalDespesas = totalDespesas;
        this.dataAtualizacao = dataAtualizacao;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public BigDecimal getSaldoAtual() {
        return saldoAtual;
    }

    public void setSaldoAtual(BigDecimal saldoAtual) {
        this.saldoAtual = saldoAtual;
    }

    public BigDecimal getTotalReceitas() {
        return totalReceitas;
    }

    public void setTotalReceitas(BigDecimal totalReceitas) {
        this.totalReceitas = totalReceitas;
    }

    public BigDecimal getTotalDespesas() {
        return totalDespesas;
    }

    public void setTotalDespesas(BigDecimal totalDespesas) {
        this.totalDespesas = totalDespesas;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}


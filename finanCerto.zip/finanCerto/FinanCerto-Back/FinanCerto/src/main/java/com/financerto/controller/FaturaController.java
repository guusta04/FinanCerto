package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.FaturaResponseDTO;
import com.financerto.dto.PagamentoFaturaRequestDTO;
import com.financerto.model.Fatura;
import com.financerto.model.Usuario;
import com.financerto.service.FaturaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/faturas")
public class FaturaController {

    private final FaturaService faturaService;

    public FaturaController(FaturaService faturaService) {
        this.faturaService = faturaService;
    }

    @GetMapping("/cartao/{cartaoId}")
    public ResponseEntity<List<FaturaResponseDTO>> listarPorCartao(@PathVariable Long cartaoId,
                                                                     @AuthenticationPrincipal Usuario usuarioLogado) {
        List<FaturaResponseDTO> faturas = faturaService.listarPorCartao(cartaoId, usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();

        return ResponseEntity.ok(faturas);
    }

    @PatchMapping("/{id}/pagamentos")
    public ResponseEntity<FaturaResponseDTO> registrarPagamento(@PathVariable Long id,
                                                                  @Valid @RequestBody PagamentoFaturaRequestDTO dados,
                                                                  @AuthenticationPrincipal Usuario usuarioLogado) {
        Fatura fatura = faturaService.registrarPagamento(id, dados.getValor(), usuarioLogado);
        return ResponseEntity.ok(toResponseDTO(fatura));
    }

    private FaturaResponseDTO toResponseDTO(Fatura fatura) {
        return new FaturaResponseDTO(
                fatura.getId(),
                fatura.getCartaoCredito().getId(),
                fatura.getDataFatura(),
                fatura.getDataVencimento(),
                fatura.getValorTotal(),
                fatura.getValorPago(),
                fatura.getValorPendente(),
                fatura.getStatus().name()
        );
    }
}
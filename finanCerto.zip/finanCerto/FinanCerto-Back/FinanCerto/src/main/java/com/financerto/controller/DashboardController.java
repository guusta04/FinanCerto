package com.financerto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.DashboardResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.DashboardService;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping
    public ResponseEntity<DashboardResponseDTO> montar(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(dashboardService.montar(usuarioLogado));
    }
}
package com.financerto.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.NotificacaoResponseDTO;
import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;
import com.financerto.service.NotificacaoService;

@RestController
@RequestMapping("/notificacoes")
public class NotificacaoController {

    private final NotificacaoService notificacaoService;

    public NotificacaoController(NotificacaoService notificacaoService) {
        this.notificacaoService = notificacaoService;
    }

    @GetMapping
    public ResponseEntity<List<NotificacaoResponseDTO>> listar(@AuthenticationPrincipal Usuario usuarioLogado) {
        List<NotificacaoResponseDTO> notificacoes = notificacaoService.listar(usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();

        return ResponseEntity.ok(notificacoes);
    }

    @GetMapping("/nao-lidas/contagem")
    public ResponseEntity<Map<String, Long>> contarNaoLidas(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(Map.of("naoLidas", notificacaoService.contarNaoLidas(usuarioLogado)));
    }

    @PatchMapping("/{id}/lida")
    public ResponseEntity<NotificacaoResponseDTO> marcarComoLida(@PathVariable Long id,
                                                                   @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(toResponseDTO(notificacaoService.marcarComoLida(id, usuarioLogado)));
    }

    private NotificacaoResponseDTO toResponseDTO(Notificacao notificacao) {
        return new NotificacaoResponseDTO(
                notificacao.getId(),
                notificacao.getUsuario().getId(),
                notificacao.getTitulo(),
                notificacao.getConteudo(),
                notificacao.getTipo().name(),
                notificacao.getDataCriacao(),
                notificacao.getLida(),
                notificacao.getDataLeitura()
        );
    }
}

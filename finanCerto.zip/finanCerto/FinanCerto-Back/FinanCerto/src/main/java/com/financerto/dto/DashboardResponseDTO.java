package com.financerto.dto;

import java.math.BigDecimal;
import java.util.List;

public class DashboardResponseDTO {

    private BigDecimal saldoAtual;
    private BigDecimal totalReceitas;
    private BigDecimal totalDespesas;
    private long notificacoesNaoLidas;
    private long alertasNaoLidos;
    private List<MetaFinanceiraResponseDTO> metasAtivas;
    private List<CartaoCreditoResponseDTO> cartoesAtivos;

    public DashboardResponseDTO(BigDecimal saldoAtual, BigDecimal totalReceitas, BigDecimal totalDespesas,
                                 long notificacoesNaoLidas, long alertasNaoLidos,
                                 List<MetaFinanceiraResponseDTO> metasAtivas,
                                 List<CartaoCreditoResponseDTO> cartoesAtivos) {
        this.saldoAtual = saldoAtual;
        this.totalReceitas = totalReceitas;
        this.totalDespesas = totalDespesas;
        this.notificacoesNaoLidas = notificacoesNaoLidas;
        this.alertasNaoLidos = alertasNaoLidos;
        this.metasAtivas = metasAtivas;
        this.cartoesAtivos = cartoesAtivos;
    }

    public BigDecimal getSaldoAtual() { return saldoAtual; }
    public BigDecimal getTotalReceitas() { return totalReceitas; }
    public BigDecimal getTotalDespesas() { return totalDespesas; }
    public long getNotificacoesNaoLidas() { return notificacoesNaoLidas; }
    public long getAlertasNaoLidos() { return alertasNaoLidos; }
    public List<MetaFinanceiraResponseDTO> getMetasAtivas() { return metasAtivas; }
    public List<CartaoCreditoResponseDTO> getCartoesAtivos() { return cartoesAtivos; }
}

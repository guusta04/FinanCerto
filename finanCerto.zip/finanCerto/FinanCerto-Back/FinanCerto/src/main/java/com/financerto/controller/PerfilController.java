package com.financerto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.AlterarSenhaRequestDTO;
import com.financerto.dto.AtualizarPerfilRequestDTO;
import com.financerto.dto.PerfilResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.UsuarioService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/perfil")
public class PerfilController {

    private final UsuarioService usuarioService;

    public PerfilController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public ResponseEntity<PerfilResponseDTO> buscar(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(usuarioService.buscarPerfil(usuarioLogado));
    }

    @PutMapping
    public ResponseEntity<PerfilResponseDTO> atualizar(@Valid @RequestBody AtualizarPerfilRequestDTO dados,
                                                        @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(usuarioService.atualizarPerfil(usuarioLogado, dados));
    }

    @PatchMapping("/senha")
    public ResponseEntity<Void> alterarSenha(@Valid @RequestBody AlterarSenhaRequestDTO dados,
                                              @AuthenticationPrincipal Usuario usuarioLogado) {
        usuarioService.alterarSenha(usuarioLogado, dados);
        return ResponseEntity.noContent().build();
    }
}
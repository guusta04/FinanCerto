package com.financerto.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "meta_financeira")
public class MetaFinanceira {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @Column(nullable = false)
    private String descricao;

    @Column(nullable = false)
    private BigDecimal valorMeta;

    @Column(nullable = false)
    private BigDecimal valorAtual = BigDecimal.ZERO;

    @Column(nullable = false)
    private LocalDate dataMeta;

    @Column(nullable = false)
    private LocalDate dataCriacao = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusMetaFinanceira status = StatusMetaFinanceira.ATIVA;

    // Construtores
    public MetaFinanceira() {}

    public MetaFinanceira(Usuario usuario, String descricao, BigDecimal valorMeta, LocalDate dataMeta) {
        this.usuario = usuario;
        this.descricao = descricao;
        this.valorMeta = valorMeta;
        this.dataMeta = dataMeta;
        this.status = StatusMetaFinanceira.ATIVA;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValorMeta() {
        return valorMeta;
    }

    public void setValorMeta(BigDecimal valorMeta) {
        this.valorMeta = valorMeta;
    }

    public BigDecimal getValorAtual() {
        return valorAtual;
    }

    public void setValorAtual(BigDecimal valorAtual) {
        this.valorAtual = valorAtual;
    }

    public LocalDate getDataMeta() {
        return dataMeta;
    }

    public void setDataMeta(LocalDate dataMeta) {
        this.dataMeta = dataMeta;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public StatusMetaFinanceira getStatus() {
        return status;
    }

    public void setStatus(StatusMetaFinanceira status) {
        this.status = status;
    }

    // Método auxiliar para calcular percentual de progresso
    public BigDecimal getPercentualProgresso() {
        if (valorMeta.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        return valorAtual.multiply(new BigDecimal("100"))
                .divide(valorMeta, 2, java.math.RoundingMode.HALF_UP);
    }

    // Enum para Status da Meta
    public enum StatusMetaFinanceira {
        ATIVA, CONCLUIDA, CANCELADA
    }
}


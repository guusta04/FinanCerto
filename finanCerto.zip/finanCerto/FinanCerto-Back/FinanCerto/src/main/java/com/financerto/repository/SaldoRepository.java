package com.financerto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.Saldo;
import com.financerto.model.Usuario;

@Repository
public interface SaldoRepository extends JpaRepository<Saldo, Long> {
    
    Optional<Saldo> findByUsuario(Usuario usuario);
    
    Optional<Saldo> findByUsuarioId(Long usuarioId);
}


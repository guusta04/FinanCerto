package com.financerto.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.CartaoCreditoRequestDTO;
import com.financerto.dto.CartaoCreditoResponseDTO;
import com.financerto.model.CartaoCredito;
import com.financerto.model.Usuario;
import com.financerto.repository.CartaoCreditoRepository;

@Service
public class CartaoCreditoService {

    private final CartaoCreditoRepository cartaoRepository;

    public CartaoCreditoService(CartaoCreditoRepository cartaoRepository) {
        this.cartaoRepository = cartaoRepository;
    }

    public CartaoCreditoResponseDTO criar(
            CartaoCreditoRequestDTO dados,
            Usuario usuarioLogado) {

        CartaoCredito.BandeiraCartao bandeira;

        try {
            bandeira = CartaoCredito.BandeiraCartao
                    .valueOf(dados.getBandeira().toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Bandeira inválida. Use VISA, MASTERCARD, ELO ou AMEX");
        }

        CartaoCredito cartao = new CartaoCredito(
                usuarioLogado,
                dados.getNumeroCartao(),
                dados.getNomeCartao(),
                dados.getLimiteCartao(),
                dados.getDataValidade(),
                bandeira,
                dados.getDiaVencimento()
        );

        cartao = cartaoRepository.save(cartao);

        return toResponseDTO(cartao);
    }

    public List<CartaoCreditoResponseDTO> listar(
            Usuario usuarioLogado) {

        return cartaoRepository
                .findByUsuario(usuarioLogado)
                .stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public CartaoCreditoResponseDTO buscar(
            Long id,
            Usuario usuarioLogado) {

        CartaoCredito cartao = cartaoRepository
                .findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Cartão não encontrado"));

        return toResponseDTO(cartao);
    }

    public void excluir(Long id, Usuario usuarioLogado) {

        CartaoCredito cartao = cartaoRepository
                .findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Cartão não encontrado"));

        cartaoRepository.delete(cartao);
    }

    private CartaoCreditoResponseDTO toResponseDTO(
            CartaoCredito cartao) {

        return new CartaoCreditoResponseDTO(
                cartao.getId(),
                cartao.getUsuario().getId(),
                cartao.getNumeroCartao(),
                cartao.getNomeCartao(),
                cartao.getLimiteCartao(),
                cartao.getSaldoDisponivel(),
                cartao.getSaldoUsado(),
                cartao.getDataValidade(),
                cartao.getBandeira().name(),
                cartao.getDiaVencimento(),
                cartao.getDataCriacao(),
                cartao.getStatus().name(),
                cartao.getPercentualUso()
        );
    }
}

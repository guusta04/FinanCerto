package com.financerto.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.GraficoCategoriaDTO;
import com.financerto.dto.GraficoEvolucaoMensalDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Usuario;
import com.financerto.service.GraficoService;

@RestController
@RequestMapping("/graficos")
public class GraficoController {

    private final GraficoService graficoService;

    public GraficoController(GraficoService graficoService) {
        this.graficoService = graficoService;
    }

    @GetMapping("/categorias")
    public ResponseEntity<List<GraficoCategoriaDTO>> porCategoria(
            @AuthenticationPrincipal Usuario usuarioLogado,
            @RequestParam(required = false) TipoMovimentacao tipo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFim) {

        return ResponseEntity.ok(graficoService.porCategoria(usuarioLogado, tipo, dataInicio, dataFim));
    }

    @GetMapping("/evolucao-mensal")
    public ResponseEntity<List<GraficoEvolucaoMensalDTO>> evolucaoMensal(
            @AuthenticationPrincipal Usuario usuarioLogado,
            @RequestParam(defaultValue = "6") int meses) {

        return ResponseEntity.ok(graficoService.evolucaoMensal(usuarioLogado, meses));
    }
}   

package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

public class CompraRequestDTO {

    @NotNull(message = "ID do cartão é obrigatório")
    private Long cartaoId;

    @NotBlank(message = "Descrição é obrigatória")
    @Size(min = 3, max = 150, message = "Descrição deve ter entre 3 e 150 caracteres")
    private String descricao;

    @NotNull(message = "Valor é obrigatório")
    @DecimalMin(value = "0.01", message = "Valor deve ser maior que 0")
    private BigDecimal valor;

    @Min(value = 1, message = "Deve ter no mínimo 1 parcela")
    @Max(value = 36, message = "Máximo de 36 parcelas")
    private Integer parcelasTotal = 1;

    @NotNull(message = "Data da compra é obrigatória")
    @PastOrPresent(message = "Data deve ser no passado ou presente")
    private LocalDate dataCompra;

    // Construtores
    public CompraRequestDTO() {}

    public CompraRequestDTO(Long cartaoId, String descricao, BigDecimal valor,
                           Integer parcelasTotal, LocalDate dataCompra) {
        this.cartaoId = cartaoId;
        this.descricao = descricao;
        this.valor = valor;
        this.parcelasTotal = parcelasTotal;
        this.dataCompra = dataCompra;
    }

    // Getters e Setters
    public Long getCartaoId() {
        return cartaoId;
    }

    public void setCartaoId(Long cartaoId) {
        this.cartaoId = cartaoId;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Integer getParcelasTotal() {
        return parcelasTotal;
    }

    public void setParcelasTotal(Integer parcelasTotal) {
        this.parcelasTotal = parcelasTotal;
    }

    public LocalDate getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(LocalDate dataCompra) {
        this.dataCompra = dataCompra;
    }
}


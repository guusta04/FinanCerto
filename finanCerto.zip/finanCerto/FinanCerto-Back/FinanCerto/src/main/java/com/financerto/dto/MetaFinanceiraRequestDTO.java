package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class MetaFinanceiraRequestDTO {

    @NotBlank(message = "Descrição é obrigatória")
    @Size(min = 3, max = 100, message = "Descrição deve ter entre 3 e 100 caracteres")
    private String descricao;

    @NotNull(message = "Valor da meta é obrigatório")
    @DecimalMin(value = "0.01", message = "Valor deve ser maior que 0")
    private BigDecimal valorMeta;

    @NotNull(message = "Data da meta é obrigatória")
    @FutureOrPresent(message = "Data deve ser no presente ou futuro")
    private LocalDate dataMeta;

    // Construtores
    public MetaFinanceiraRequestDTO() {}

    public MetaFinanceiraRequestDTO(String descricao, BigDecimal valorMeta, LocalDate dataMeta) {
        this.descricao = descricao;
        this.valorMeta = valorMeta;
        this.dataMeta = dataMeta;
    }

    // Getters e Setters
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValorMeta() {
        return valorMeta;
    }

    public void setValorMeta(BigDecimal valorMeta) {
        this.valorMeta = valorMeta;
    }

    public LocalDate getDataMeta() {
        return dataMeta;
    }

    public void setDataMeta(LocalDate dataMeta) {
        this.dataMeta = dataMeta;
    }
}


package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CartaoCreditoResponseDTO {

    private Long id;
    private Long usuarioId;
    private String numeroCartao;
    private String nomeCartao;
    private BigDecimal limiteCartao;
    private BigDecimal saldoDisponivel;
    private BigDecimal saldoUsado;
    private LocalDate dataValidade;
    private String bandeira;
    private Integer diaVencimento;
    private LocalDate dataCriacao;
    private String status;
    private BigDecimal percentualUso;

    // Construtores
    public CartaoCreditoResponseDTO() {}

    public CartaoCreditoResponseDTO(Long id, Long usuarioId, String numeroCartao,
                                     String nomeCartao, BigDecimal limiteCartao,
                                     BigDecimal saldoDisponivel, BigDecimal saldoUsado,
                                     LocalDate dataValidade, String bandeira,
                                     Integer diaVencimento, LocalDate dataCriacao,
                                     String status, BigDecimal percentualUso) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.numeroCartao = numeroCartao;
        this.nomeCartao = nomeCartao;
        this.limiteCartao = limiteCartao;
        this.saldoDisponivel = saldoDisponivel;
        this.saldoUsado = saldoUsado;
        this.dataValidade = dataValidade;
        this.bandeira = bandeira;
        this.diaVencimento = diaVencimento;
        this.dataCriacao = dataCriacao;
        this.status = status;
        this.percentualUso = percentualUso;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public String getNomeCartao() {
        return nomeCartao;
    }

    public void setNomeCartao(String nomeCartao) {
        this.nomeCartao = nomeCartao;
    }

    public BigDecimal getLimiteCartao() {
        return limiteCartao;
    }

    public void setLimiteCartao(BigDecimal limiteCartao) {
        this.limiteCartao = limiteCartao;
    }

    public BigDecimal getSaldoDisponivel() {
        return saldoDisponivel;
    }

    public void setSaldoDisponivel(BigDecimal saldoDisponivel) {
        this.saldoDisponivel = saldoDisponivel;
    }

    public BigDecimal getSaldoUsado() {
        return saldoUsado;
    }

    public void setSaldoUsado(BigDecimal saldoUsado) {
        this.saldoUsado = saldoUsado;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public String getBandeira() {
        return bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    public Integer getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(Integer diaVencimento) {
        this.diaVencimento = diaVencimento;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getPercentualUso() {
        return percentualUso;
    }

    public void setPercentualUso(BigDecimal percentualUso) {
        this.percentualUso = percentualUso;
    }
}


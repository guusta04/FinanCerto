package com.financerto.enums;

public enum TipoMovimentacao {
    RECEITA,
    DESPESA
}

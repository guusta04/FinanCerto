package com.financerto.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.model.CartaoCredito;
import com.financerto.model.Fatura;
import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;
import com.financerto.repository.CartaoCreditoRepository;
import com.financerto.repository.FaturaRepository;

@Service
public class FaturaService {

    private final FaturaRepository faturaRepository;
    private final CartaoCreditoRepository cartaoRepository;
    private final NotificacaoService notificacaoService;

    public FaturaService(FaturaRepository faturaRepository,
                          CartaoCreditoRepository cartaoRepository,
                          NotificacaoService notificacaoService) {
        this.faturaRepository = faturaRepository;
        this.cartaoRepository = cartaoRepository;
        this.notificacaoService = notificacaoService;
    }

    public Fatura obterOuCriarFaturaAtual(CartaoCredito cartao, LocalDate dataCompra) {
        LocalDate dataFatura = dataCompra.withDayOfMonth(1);

        return faturaRepository.findByCartaoCredito_IdAndDataFatura(cartao.getId(), dataFatura)
                .orElseGet(() -> {
                    int diaVencimento = Math.min(cartao.getDiaVencimento(), 28);
                    LocalDate vencimento = dataFatura.plusMonths(1).withDayOfMonth(diaVencimento);
                    Fatura nova = new Fatura(cartao, dataFatura, vencimento);
                    nova = faturaRepository.save(nova);

                    notificacaoService.criar(cartao.getUsuario(), "Fatura gerada",
                            "Uma nova fatura foi aberta para o cartao " + cartao.getNomeCartao(),
                            Notificacao.TipoNotificacao.FATURA_GERADA);

                    return nova;
                });
    }

    public void adicionarValor(Fatura fatura, BigDecimal valor) {
        fatura.setValorTotal(fatura.getValorTotal().add(valor));
        faturaRepository.save(fatura);
    }

    public void removerValor(Fatura fatura, BigDecimal valor) {
        if (fatura.getStatus() == Fatura.StatusFatura.ABERTA) {
            fatura.setValorTotal(fatura.getValorTotal().subtract(valor));
            faturaRepository.save(fatura);
        }
    }

    public List<Fatura> listarPorCartao(Long cartaoId, Usuario usuarioLogado) {
        cartaoRepository.findByIdAndUsuarioId(cartaoId, usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Cartao nao encontrado"));

        return faturaRepository.findByCartaoCredito_Id(cartaoId);
    }

    public Fatura registrarPagamento(Long id, BigDecimal valor, Usuario usuarioLogado) {
        Fatura fatura = faturaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Fatura nao encontrada"));

        if (!fatura.getCartaoCredito().getUsuario().getId().equals(usuarioLogado.getId())) {
            throw new IllegalArgumentException("Voce nao tem permissao para acessar essa fatura");
        }

        fatura.setValorPago(fatura.getValorPago().add(valor));

        if (fatura.getValorPago().compareTo(fatura.getValorTotal()) >= 0) {
            fatura.setStatus(Fatura.StatusFatura.PAGA);
        } else if (fatura.getValorPago().compareTo(BigDecimal.ZERO) > 0) {
            fatura.setStatus(Fatura.StatusFatura.PARCIALMENTE_PAGA);
        }

        return faturaRepository.save(fatura);
    }
}
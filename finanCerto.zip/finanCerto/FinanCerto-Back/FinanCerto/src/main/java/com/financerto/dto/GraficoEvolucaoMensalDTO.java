package com.financerto.dto;

import java.math.BigDecimal;

public class GraficoEvolucaoMensalDTO {
    private String mes;
    private BigDecimal totalReceitas;
    private BigDecimal totalDespesas;

    public GraficoEvolucaoMensalDTO(String mes, BigDecimal totalReceitas, BigDecimal totalDespesas) {
        this.mes = mes;
        this.totalReceitas = totalReceitas;
        this.totalDespesas = totalDespesas;
    }

    public String getMes() { return mes; }
    public BigDecimal getTotalReceitas() { return totalReceitas; }
    public BigDecimal getTotalDespesas() { return totalDespesas; }
}

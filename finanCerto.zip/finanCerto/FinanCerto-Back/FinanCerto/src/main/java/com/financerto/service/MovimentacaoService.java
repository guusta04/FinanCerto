package com.financerto.service;

import com.financerto.dto.MovimentacaoRequestDTO;
import com.financerto.dto.MovimentacaoResponseDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Categoria;
import com.financerto.model.Movimentacao;
import com.financerto.model.Usuario;
import com.financerto.repository.CategoriaRepository;
import com.financerto.repository.MovimentacaoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class MovimentacaoService {

    private final MovimentacaoRepository movimentacaoRepository;
    private final CategoriaRepository categoriaRepository;
    private final SaldoService saldoService;

    public MovimentacaoService(MovimentacaoRepository movimentacaoRepository,
                                CategoriaRepository categoriaRepository,
                                SaldoService saldoService) {
        this.movimentacaoRepository = movimentacaoRepository;
        this.categoriaRepository = categoriaRepository;
        this.saldoService = saldoService;
    }

    public MovimentacaoResponseDTO cadastrar(MovimentacaoRequestDTO dados, Usuario usuarioLogado) {
        Categoria categoria = categoriaRepository.findById(dados.getCategoriaId())
                .orElseThrow(() -> new IllegalArgumentException("Categoria nao encontrada"));

        Movimentacao movimentacao = new Movimentacao();
        movimentacao.setDescricao(dados.getDescricao());
        movimentacao.setValor(dados.getValor());
        movimentacao.setData(dados.getData());
        movimentacao.setTipo(dados.getTipo());
        movimentacao.setCategoria(categoria);
        movimentacao.setUsuario(usuarioLogado);

        movimentacao = movimentacaoRepository.save(movimentacao);
        saldoService.recalcular(usuarioLogado);

        return toResponseDTO(movimentacao);
    }

    public List<MovimentacaoResponseDTO> listar(Usuario usuarioLogado, TipoMovimentacao tipo,
                                                 Long categoriaId, LocalDate dataInicio, LocalDate dataFim) {
        return movimentacaoRepository.filtrar(usuarioLogado, tipo, categoriaId, dataInicio, dataFim).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public MovimentacaoResponseDTO editar(Long id, MovimentacaoRequestDTO dados, Usuario usuarioLogado) {
        Movimentacao movimentacao = buscarDoUsuario(id, usuarioLogado);

        Categoria categoria = categoriaRepository.findById(dados.getCategoriaId())
                .orElseThrow(() -> new IllegalArgumentException("Categoria nao encontrada"));

        movimentacao.setDescricao(dados.getDescricao());
        movimentacao.setValor(dados.getValor());
        movimentacao.setData(dados.getData());
        movimentacao.setTipo(dados.getTipo());
        movimentacao.setCategoria(categoria);

        movimentacao = movimentacaoRepository.save(movimentacao);
        saldoService.recalcular(usuarioLogado);

        return toResponseDTO(movimentacao);
    }

    public void excluir(Long id, Usuario usuarioLogado) {
        Movimentacao movimentacao = buscarDoUsuario(id, usuarioLogado);
        movimentacaoRepository.delete(movimentacao);
        saldoService.recalcular(usuarioLogado);
    }

    private Movimentacao buscarDoUsuario(Long id, Usuario usuarioLogado) {
        Movimentacao movimentacao = movimentacaoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Movimentacao nao encontrada"));

        if (!movimentacao.getUsuario().getId().equals(usuarioLogado.getId())) {
            throw new IllegalArgumentException("Voce nao tem permissao para acessar essa movimentacao");
        }

        return movimentacao;
    }

    private MovimentacaoResponseDTO toResponseDTO(Movimentacao movimentacao) {
        return new MovimentacaoResponseDTO(
                movimentacao.getId(),
                movimentacao.getDescricao(),
                movimentacao.getValor(),
                movimentacao.getData(),
                movimentacao.getTipo(),
                movimentacao.getCategoria().getNome()
        );
    }
}
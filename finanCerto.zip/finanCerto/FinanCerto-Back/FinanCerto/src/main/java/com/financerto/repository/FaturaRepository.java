package com.financerto.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.CartaoCredito;
import com.financerto.model.Fatura;

@Repository
public interface FaturaRepository extends JpaRepository<Fatura, Long> {

    List<Fatura> findByCartaoCredito(CartaoCredito cartaoCredito);

    List<Fatura> findByCartaoCredito_Id(Long cartaoId);

    List<Fatura> findByStatus(Fatura.StatusFatura status);

    List<Fatura> findByDataFaturaBetween(
            LocalDate dataInicio,
            LocalDate dataFim
    );

    List<Fatura> findByDataVencimentoBetween(
            LocalDate dataInicio,
            LocalDate dataFim
    );

    List<Fatura> findByDataVencimentoBeforeAndStatus(
            LocalDate data,
            Fatura.StatusFatura status
    );

    Optional<Fatura> findByCartaoCredito_IdAndDataFatura(
            Long cartaoId,
            LocalDate dataFatura
    );

    List<Fatura> findByCartaoCredito_IdAndStatusOrderByDataVencimentoDesc(
            Long cartaoId,
            Fatura.StatusFatura status
    );
}
package com.financerto.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.financerto.dto.GraficoCategoriaDTO;
import com.financerto.dto.GraficoEvolucaoMensalDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Movimentacao;
import com.financerto.model.Usuario;
import com.financerto.repository.MovimentacaoRepository;

@Service
public class GraficoService {

    private final MovimentacaoRepository movimentacaoRepository;

    public GraficoService(MovimentacaoRepository movimentacaoRepository) {
        this.movimentacaoRepository = movimentacaoRepository;
    }

    public List<GraficoCategoriaDTO> porCategoria(Usuario usuarioLogado, TipoMovimentacao tipo,
                                                    LocalDate dataInicio, LocalDate dataFim) {
        List<Movimentacao> movimentacoes = movimentacaoRepository.filtrar(usuarioLogado, tipo, null, dataInicio, dataFim);

        Map<String, BigDecimal> porCategoria = movimentacoes.stream()
                .collect(Collectors.groupingBy(
                        m -> m.getCategoria().getNome(),
                        Collectors.reducing(BigDecimal.ZERO, Movimentacao::getValor, BigDecimal::add)
                ));

        return porCategoria.entrySet().stream()
                .map(e -> new GraficoCategoriaDTO(e.getKey(), e.getValue()))
                .sorted(Comparator.comparing(GraficoCategoriaDTO::getTotal).reversed())
                .toList();
    }

    public List<GraficoEvolucaoMensalDTO> evolucaoMensal(Usuario usuarioLogado, int meses) {
        LocalDate dataInicio = LocalDate.now().minusMonths(meses - 1L).withDayOfMonth(1);

        List<Movimentacao> movimentacoes = movimentacaoRepository.filtrar(
                usuarioLogado, null, null, dataInicio, LocalDate.now());

        Map<YearMonth, List<Movimentacao>> porMes = movimentacoes.stream()
                .collect(Collectors.groupingBy(m -> YearMonth.from(m.getData()), TreeMap::new, Collectors.toList()));

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");

        return porMes.entrySet().stream()
                .map(entry -> {
                    BigDecimal receitas = entry.getValue().stream()
                            .filter(m -> m.getTipo() == TipoMovimentacao.RECEITA)
                            .map(Movimentacao::getValor)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    BigDecimal despesas = entry.getValue().stream()
                            .filter(m -> m.getTipo() == TipoMovimentacao.DESPESA)
                            .map(Movimentacao::getValor)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    return new GraficoEvolucaoMensalDTO(entry.getKey().format(formatter), receitas, despesas);
                })
                .toList();
    }
}

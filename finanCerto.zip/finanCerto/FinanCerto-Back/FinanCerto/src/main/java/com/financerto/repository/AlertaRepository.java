package com.financerto.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.Alerta;
import com.financerto.model.Usuario;

@Repository
public interface AlertaRepository extends JpaRepository<Alerta, Long> {
    
    List<Alerta> findByUsuario(Usuario usuario);
    
    List<Alerta> findByUsuarioId(Long usuarioId);
    
    List<Alerta> findByUsuarioAndLido(Usuario usuario, Boolean lido);
    
    List<Alerta> findByUsuarioIdAndLido(Long usuarioId, Boolean lido);
    
    List<Alerta> findByTipo(Alerta.TipoAlerta tipo);
    
    List<Alerta> findByUsuarioIdAndTipo(Long usuarioId, Alerta.TipoAlerta tipo);
    
    List<Alerta> findByDataCriacao(LocalDateTime data);
    
    List<Alerta> findByDataCriacao(LocalDateTime dataInicio, LocalDateTime dataFim);
    
    List<Alerta> findByUsuarioIdAndDataCriacaoBetween(Long usuarioId, 
            LocalDateTime dataInicio, LocalDateTime dataFim);
    
    Optional<Alerta> findByIdAndUsuarioId(Long id, Long usuarioId);
    
    Long countByUsuarioIdAndLido(Long usuarioId, Boolean lido);
}


package com.financerto.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.MetaFinanceira;
import com.financerto.model.Usuario;

@Repository
public interface MetaFinanceiraRepository extends JpaRepository<MetaFinanceira, Long> {
    
    List<MetaFinanceira> findByUsuario(Usuario usuario);
    
    List<MetaFinanceira> findByUsuarioId(Long usuarioId);
    
    List<MetaFinanceira> findByUsuarioAndStatus(Usuario usuario, 
            MetaFinanceira.StatusMetaFinanceira status);
    
    List<MetaFinanceira> findByUsuarioIdAndStatus(Long usuarioId, 
            MetaFinanceira.StatusMetaFinanceira status);
    
    List<MetaFinanceira> findByDataMetaBetween(LocalDate dataInicio, LocalDate dataFim);
    
    List<MetaFinanceira> findByUsuarioIdAndDataMetaBetween(Long usuarioId, 
            LocalDate dataInicio, LocalDate dataFim);
    
    Optional<MetaFinanceira> findByIdAndUsuarioId(Long id, Long usuarioId);
}


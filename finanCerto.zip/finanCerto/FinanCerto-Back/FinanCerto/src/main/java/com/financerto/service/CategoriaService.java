package com.financerto.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.CategoriaRequestDTO;
import com.financerto.dto.CategoriaResponseDTO;
import com.financerto.model.Categoria;
import com.financerto.repository.CategoriaRepository;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public CategoriaResponseDTO criar(CategoriaRequestDTO dados) {
        Categoria categoria = new Categoria();
        categoria.setNome(dados.getNome());
        categoria.setTipo(dados.getTipo());
        categoria = categoriaRepository.save(categoria);
        return toResponseDTO(categoria);
    }

    public List<CategoriaResponseDTO> listar() {
        return categoriaRepository.findAll().stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public void excluir(Long id) {
        if (!categoriaRepository.existsById(id)) {
            throw new IllegalArgumentException("Categoria não encontrada");
        }

        categoriaRepository.deleteById(id);
    }

    private CategoriaResponseDTO toResponseDTO(Categoria categoria) {
        return new CategoriaResponseDTO(categoria.getId(), categoria.getNome(), categoria.getTipo());
    }
}
package com.financerto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.CadastroUsuarioDTO;
import com.financerto.dto.LoginDTO;
import com.financerto.dto.TokenDTO;
import com.financerto.model.Usuario;
import com.financerto.security.JwtService;
import com.financerto.service.UsuarioService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UsuarioService usuarioService;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthController(UsuarioService usuarioService,
                           AuthenticationManager authenticationManager,
                           JwtService jwtService) {
        this.usuarioService = usuarioService;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<Usuario> cadastrar(@Valid @RequestBody CadastroUsuarioDTO dados) {
        Usuario usuario = usuarioService.cadastrar(dados);
        return ResponseEntity.ok(usuario);
    }

    @PostMapping("/login")
    public ResponseEntity<TokenDTO> login(@Valid @RequestBody LoginDTO dados) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(dados.getEmail(), dados.getSenha())
        );

        UserDetails usuarioAutenticado = (UserDetails) auth.getPrincipal();
        String token = jwtService.gerarToken(usuarioAutenticado);

        return ResponseEntity.ok(new TokenDTO(token));
    }
}
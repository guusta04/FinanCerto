package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class RelatorioResponseDTO {

    private LocalDate dataInicio;
    private LocalDate dataFim;
    private BigDecimal totalReceitas;
    private BigDecimal totalDespesas;
    private BigDecimal saldoPeriodo;
    private List<GraficoCategoriaDTO> despesasPorCategoria;

    public RelatorioResponseDTO(LocalDate dataInicio, LocalDate dataFim, BigDecimal totalReceitas,
                                 BigDecimal totalDespesas, BigDecimal saldoPeriodo,
                                 List<GraficoCategoriaDTO> despesasPorCategoria) {
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.totalReceitas = totalReceitas;
        this.totalDespesas = totalDespesas;
        this.saldoPeriodo = saldoPeriodo;
        this.despesasPorCategoria = despesasPorCategoria;
    }

    public LocalDate getDataInicio() { return dataInicio; }
    public LocalDate getDataFim() { return dataFim; }
    public BigDecimal getTotalReceitas() { return totalReceitas; }
    public BigDecimal getTotalDespesas() { return totalDespesas; }
    public BigDecimal getSaldoPeriodo() { return saldoPeriodo; }
    public List<GraficoCategoriaDTO> getDespesasPorCategoria() { return despesasPorCategoria; }
}
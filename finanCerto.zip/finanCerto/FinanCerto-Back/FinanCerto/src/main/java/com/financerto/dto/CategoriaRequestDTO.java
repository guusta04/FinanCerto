package com.financerto.dto;

import com.financerto.enums.TipoMovimentacao;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CategoriaRequestDTO {

    @NotBlank(message = "O nome da categoria é obrigatório")
    private String nome;

    @NotNull(message = "O tipo da categoria é obrigatório (RECEITA ou DESPESA)")
    private TipoMovimentacao tipo;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public TipoMovimentacao getTipo() { return tipo; }
    public void setTipo(TipoMovimentacao tipo) { this.tipo = tipo; }
}
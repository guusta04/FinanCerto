package com.financerto.dto;

import com.financerto.enums.TipoMovimentacao;

public class CategoriaResponseDTO {

    private Long id;
    private String nome;
    private TipoMovimentacao tipo;

    public CategoriaResponseDTO(Long id, String nome, TipoMovimentacao tipo) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public TipoMovimentacao getTipo() { return tipo; }
}

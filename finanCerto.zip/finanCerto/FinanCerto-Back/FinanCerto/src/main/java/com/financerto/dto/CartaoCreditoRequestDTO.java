package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CartaoCreditoRequestDTO {

    @NotBlank(message = "Número do cartão é obrigatório")
    @Size(min = 16, max = 16, message = "Número deve ter 16 dígitos")
    @Pattern(regexp = "\\d{16}", message = "Número deve conter apenas dígitos")
    private String numeroCartao;

    @NotBlank(message = "Nome do cartão é obrigatório")
    @Size(min = 3, max = 50, message = "Nome deve ter entre 3 e 50 caracteres")
    private String nomeCartao;

    @NotNull(message = "Limite do cartão é obrigatório")
    @DecimalMin(value = "100", message = "Limite mínimo é 100")
    private BigDecimal limiteCartao;

    @NotNull(message = "Data de validade é obrigatória")
    @FutureOrPresent(message = "Data deve ser no futuro")
    private LocalDate dataValidade;

    @NotBlank(message = "Bandeira é obrigatória")
    private String bandeira;

    @NotNull(message = "Dia de vencimento é obrigatório")
    @Min(value = 1, message = "Dia deve ser entre 1 e 31")
    @Max(value = 31, message = "Dia deve ser entre 1 e 31")
    private Integer diaVencimento;

    // Construtores
    public CartaoCreditoRequestDTO() {}

    public CartaoCreditoRequestDTO(String numeroCartao, String nomeCartao,
                                   BigDecimal limiteCartao, LocalDate dataValidade,
                                   String bandeira, Integer diaVencimento) {
        this.numeroCartao = numeroCartao;
        this.nomeCartao = nomeCartao;
        this.limiteCartao = limiteCartao;
        this.dataValidade = dataValidade;
        this.bandeira = bandeira;
        this.diaVencimento = diaVencimento;
    }

    // Getters e Setters
    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public String getNomeCartao() {
        return nomeCartao;
    }

    public void setNomeCartao(String nomeCartao) {
        this.nomeCartao = nomeCartao;
    }

    public BigDecimal getLimiteCartao() {
        return limiteCartao;
    }

    public void setLimiteCartao(BigDecimal limiteCartao) {
        this.limiteCartao = limiteCartao;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public String getBandeira() {
        return bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    public Integer getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(Integer diaVencimento) {
        this.diaVencimento = diaVencimento;
    }
}


package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MetaFinanceiraResponseDTO {

    private Long id;
    private Long usuarioId;
    private String descricao;
    private BigDecimal valorMeta;
    private BigDecimal valorAtual;
    private LocalDate dataMeta;
    private LocalDate dataCriacao;
    private String status;
    private BigDecimal percentualProgresso;

    // Construtores
    public MetaFinanceiraResponseDTO() {}

    public MetaFinanceiraResponseDTO(Long id, Long usuarioId, String descricao,
                                      BigDecimal valorMeta, BigDecimal valorAtual,
                                      LocalDate dataMeta, LocalDate dataCriacao,
                                      String status, BigDecimal percentualProgresso) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.descricao = descricao;
        this.valorMeta = valorMeta;
        this.valorAtual = valorAtual;
        this.dataMeta = dataMeta;
        this.dataCriacao = dataCriacao;
        this.status = status;
        this.percentualProgresso = percentualProgresso;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValorMeta() {
        return valorMeta;
    }

    public void setValorMeta(BigDecimal valorMeta) {
        this.valorMeta = valorMeta;
    }

    public BigDecimal getValorAtual() {
        return valorAtual;
    }

    public void setValorAtual(BigDecimal valorAtual) {
        this.valorAtual = valorAtual;
    }

    public LocalDate getDataMeta() {
        return dataMeta;
    }

    public void setDataMeta(LocalDate dataMeta) {
        this.dataMeta = dataMeta;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getPercentualProgresso() {
        return percentualProgresso;
    }

    public void setPercentualProgresso(BigDecimal percentualProgresso) {
        this.percentualProgresso = percentualProgresso;
    }
}


   package com.financerto.enums;

public enum Role {
    ADMIN("admin"),
    USER("user");

    private final String valor;

    Role(String valor) {
        this.valor = valor;
    }

    public String getValor() {
        return valor;
    }
}

package com.financerto.dto;

import java.time.LocalDateTime;

public class NotificacaoResponseDTO {

    private Long id;
    private Long usuarioId;
    private String titulo;
    private String conteudo;
    private String tipo;
    private LocalDateTime dataCriacao;
    private Boolean lida;
    private LocalDateTime dataLeitura;

    // Construtores
    public NotificacaoResponseDTO() {}

    public NotificacaoResponseDTO(Long id, Long usuarioId, String titulo,
                                 String conteudo, String tipo, LocalDateTime dataCriacao,
                                 Boolean lida, LocalDateTime dataLeitura) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.tipo = tipo;
        this.dataCriacao = dataCriacao;
        this.lida = lida;
        this.dataLeitura = dataLeitura;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public Boolean getLida() {
        return lida;
    }

    public void setLida(Boolean lida) {
        this.lida = lida;
    }

    public LocalDateTime getDataLeitura() {
        return dataLeitura;
    }

    public void setDataLeitura(LocalDateTime dataLeitura) {
        this.dataLeitura = dataLeitura;
    }
}


package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.CompraRequestDTO;
import com.financerto.dto.CompraResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.CompraService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/compras")
public class CompraController {

    private final CompraService compraService;

    public CompraController(CompraService compraService) {
        this.compraService = compraService;
    }

    @PostMapping
    public ResponseEntity<CompraResponseDTO> cadastrar(@Valid @RequestBody CompraRequestDTO dados,
                                                         @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(compraService.cadastrar(dados, usuarioLogado));
    }

    @GetMapping
    public ResponseEntity<List<CompraResponseDTO>> listar(@AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(compraService.listar(usuarioLogado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id, @AuthenticationPrincipal Usuario usuarioLogado) {
        compraService.excluir(id, usuarioLogado);
        return ResponseEntity.noContent().build();
    }
}
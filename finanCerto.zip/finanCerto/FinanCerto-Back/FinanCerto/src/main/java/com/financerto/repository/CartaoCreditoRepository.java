 package com.financerto.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.financerto.model.CartaoCredito;
import com.financerto.model.Usuario;

@Repository
public interface CartaoCreditoRepository extends JpaRepository<CartaoCredito, Long> {
    
    List<CartaoCredito> findByUsuario(Usuario usuario);
    
    List<CartaoCredito> findByUsuarioId(Long usuarioId);
    
    List<CartaoCredito> findByUsuarioAndStatus(Usuario usuario, 
            CartaoCredito.StatusCartao status);
    
    List<CartaoCredito> findByUsuarioIdAndStatus(Long usuarioId, 
            CartaoCredito.StatusCartao status);
    
    Optional<CartaoCredito> findByNumeroCartao(String numeroCartao);
    
    Optional<CartaoCredito> findByIdAndUsuarioId(Long id, Long usuarioId);
    
    List<CartaoCredito> findByNomeCartao(String nomeCartao);
}

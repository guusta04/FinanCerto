package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class CompraResponseDTO {

    private Long id;
    private Long usuarioId;
    private Long cartaoId;
    private String descricao;
    private BigDecimal valor;
    private BigDecimal valorParcela;
    private Integer parcelasTotal;
    private Integer parcelaAtual;
    private LocalDate dataCompra;
    private LocalDateTime dataCriacao;
    private String status;

    // Construtores
    public CompraResponseDTO() {}

    public CompraResponseDTO(Long id, Long usuarioId, Long cartaoId, String descricao,
                            BigDecimal valor, BigDecimal valorParcela,
                            Integer parcelasTotal, Integer parcelaAtual,
                            LocalDate dataCompra, LocalDateTime dataCriacao,
                            String status) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.cartaoId = cartaoId;
        this.descricao = descricao;
        this.valor = valor;
        this.valorParcela = valorParcela;
        this.parcelasTotal = parcelasTotal;
        this.parcelaAtual = parcelaAtual;
        this.dataCompra = dataCompra;
        this.dataCriacao = dataCriacao;
        this.status = status;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Long getCartaoId() {
        return cartaoId;
    }

    public void setCartaoId(Long cartaoId) {
        this.cartaoId = cartaoId;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public BigDecimal getValorParcela() {
        return valorParcela;
    }

    public void setValorParcela(BigDecimal valorParcela) {
        this.valorParcela = valorParcela;
    }

    public Integer getParcelasTotal() {
        return parcelasTotal;
    }

    public void setParcelasTotal(Integer parcelasTotal) {
        this.parcelasTotal = parcelasTotal;
    }

    public Integer getParcelaAtual() {
        return parcelaAtual;
    }

    public void setParcelaAtual(Integer parcelaAtual) {
        this.parcelaAtual = parcelaAtual;
    }

    public LocalDate getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(LocalDate dataCompra) {
        this.dataCompra = dataCompra;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

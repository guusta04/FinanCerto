package com.financerto.dto;

import java.math.BigDecimal;

public class DashboardResumoDTO {

    private BigDecimal saldoAtual;
    private BigDecimal receitasMes;
    private BigDecimal despesasMes;
    private long metasAtivas;
    private long cartoesAtivos;
    private long notificacoesNaoLidas;
    private long alertasNaoLidos;

    public DashboardResumoDTO(BigDecimal saldoAtual, BigDecimal receitasMes, BigDecimal despesasMes,
                               long metasAtivas, long cartoesAtivos,
                               long notificacoesNaoLidas, long alertasNaoLidos) {
        this.saldoAtual = saldoAtual;
        this.receitasMes = receitasMes;
        this.despesasMes = despesasMes;
        this.metasAtivas = metasAtivas;
        this.cartoesAtivos = cartoesAtivos;
        this.notificacoesNaoLidas = notificacoesNaoLidas;
        this.alertasNaoLidos = alertasNaoLidos;
    }

    public BigDecimal getSaldoAtual() { return saldoAtual; }
    public BigDecimal getReceitasMes() { return receitasMes; }
    public BigDecimal getDespesasMes() { return despesasMes; }
    public long getMetasAtivas() { return metasAtivas; }
    public long getCartoesAtivos() { return cartoesAtivos; }
    public long getNotificacoesNaoLidas() { return notificacoesNaoLidas; }
    public long getAlertasNaoLidos() { return alertasNaoLidos; }
}
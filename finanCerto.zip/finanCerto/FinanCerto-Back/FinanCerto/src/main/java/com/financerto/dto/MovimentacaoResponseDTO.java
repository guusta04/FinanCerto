package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.financerto.enums.TipoMovimentacao;

public class MovimentacaoResponseDTO {

    private Long id;
    private String descricao;
    private BigDecimal valor;
    private LocalDate data;
    private TipoMovimentacao tipo;
    private String categoria;

    public MovimentacaoResponseDTO(Long id, String descricao, BigDecimal valor, LocalDate data,
                                    TipoMovimentacao tipo, String categoria) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.data = data;
        this.tipo = tipo;
        this.categoria = categoria;
    }

    public Long getId() { return id; }
    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getData() { return data; }
    public TipoMovimentacao getTipo() { return tipo; }
    public String getCategoria() { return categoria; }
}

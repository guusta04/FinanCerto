package com.financerto.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.MovimentacaoRequestDTO;
import com.financerto.dto.MovimentacaoResponseDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Usuario;
import com.financerto.service.MovimentacaoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/movimentacoes")
public class MovimentacaoController {

    private final MovimentacaoService movimentacaoService;

    public MovimentacaoController(MovimentacaoService movimentacaoService) {
        this.movimentacaoService = movimentacaoService;
    }

    @PostMapping
    public ResponseEntity<MovimentacaoResponseDTO> cadastrar(@Valid @RequestBody MovimentacaoRequestDTO dados,
                                                               @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(movimentacaoService.cadastrar(dados, usuarioLogado));
    }

    @GetMapping
    public ResponseEntity<List<MovimentacaoResponseDTO>> listar(
            @AuthenticationPrincipal Usuario usuarioLogado,
            @RequestParam(required = false) TipoMovimentacao tipo,
            @RequestParam(required = false) Long categoriaId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFim) {

        return ResponseEntity.ok(
                movimentacaoService.listar(usuarioLogado, tipo, categoriaId, dataInicio, dataFim)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<MovimentacaoResponseDTO> editar(@PathVariable Long id,
                                                            @Valid @RequestBody MovimentacaoRequestDTO dados,
                                                            @AuthenticationPrincipal Usuario usuarioLogado) {
        return ResponseEntity.ok(movimentacaoService.editar(id, dados, usuarioLogado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id, @AuthenticationPrincipal Usuario usuarioLogado) {
        movimentacaoService.excluir(id, usuarioLogado);
        return ResponseEntity.noContent().build();
    }

}

package com.financerto.dto;

import java.math.BigDecimal;

public class GastoPorCategoriaDTO {

    private String categoria;
    private BigDecimal total;
    private BigDecimal percentual;

    public GastoPorCategoriaDTO(String categoria, BigDecimal total, BigDecimal percentual) {
        this.categoria = categoria;
        this.total = total;
        this.percentual = percentual;
    }

    public String getCategoria() { return categoria; }
    public BigDecimal getTotal() { return total; }
    public BigDecimal getPercentual() { return percentual; }
}
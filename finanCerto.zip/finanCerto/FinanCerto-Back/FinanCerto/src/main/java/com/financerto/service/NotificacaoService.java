package com.financerto.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;
import com.financerto.repository.NotificacaoRepository;

@Service
public class NotificacaoService {

    private final NotificacaoRepository notificacaoRepository;

    public NotificacaoService(NotificacaoRepository notificacaoRepository) {
        this.notificacaoRepository = notificacaoRepository;
    }

    public void criar(Usuario usuario, String titulo, String conteudo, Notificacao.TipoNotificacao tipo) {
        Notificacao notificacao = new Notificacao(usuario, titulo, conteudo, tipo);
        notificacaoRepository.save(notificacao);
    }

    public List<Notificacao> listar(Usuario usuarioLogado) {
        return notificacaoRepository.findByUsuarioIdOrderByDataCriacaoDesc(usuarioLogado.getId());
    }

    public long contarNaoLidas(Usuario usuarioLogado) {
        return notificacaoRepository.countByUsuarioIdAndLida(usuarioLogado.getId(), false);
    }

    public Notificacao marcarComoLida(Long id, Usuario usuarioLogado) {
        Notificacao notificacao = notificacaoRepository.findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Notificacao nao encontrada"));

        notificacao.setLida(true);
        notificacao.setDataLeitura(LocalDateTime.now());

        return notificacaoRepository.save(notificacao);
    }
}

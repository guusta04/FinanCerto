package com.financerto.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.financerto.dto.GraficoCategoriaDTO;
import com.financerto.dto.RelatorioResponseDTO;
import com.financerto.enums.TipoMovimentacao;
import com.financerto.model.Movimentacao;
import com.financerto.model.Usuario;
import com.financerto.repository.MovimentacaoRepository;

@Service
public class RelatorioService {

    private final MovimentacaoRepository movimentacaoRepository;

    public RelatorioService(MovimentacaoRepository movimentacaoRepository) {
        this.movimentacaoRepository = movimentacaoRepository;
    }

    public RelatorioResponseDTO resumoPeriodo(Usuario usuarioLogado, LocalDate dataInicio, LocalDate dataFim) {
        List<Movimentacao> movimentacoes = movimentacaoRepository.filtrar(
                usuarioLogado, null, null, dataInicio, dataFim);

        BigDecimal totalReceitas = somar(movimentacoes, TipoMovimentacao.RECEITA);
        BigDecimal totalDespesas = somar(movimentacoes, TipoMovimentacao.DESPESA);

        Map<String, BigDecimal> despesasPorCategoriaMap = movimentacoes.stream()
                .filter(m -> m.getTipo() == TipoMovimentacao.DESPESA)
                .collect(Collectors.groupingBy(
                        m -> m.getCategoria().getNome(),
                        Collectors.reducing(BigDecimal.ZERO, Movimentacao::getValor, BigDecimal::add)
                ));

        List<GraficoCategoriaDTO> despesasPorCategoria = despesasPorCategoriaMap.entrySet().stream()
                .map(e -> new GraficoCategoriaDTO(e.getKey(), e.getValue()))
                .sorted(Comparator.comparing(GraficoCategoriaDTO::getTotal).reversed())
                .toList();

        return new RelatorioResponseDTO(dataInicio, dataFim, totalReceitas, totalDespesas,
                totalReceitas.subtract(totalDespesas), despesasPorCategoria);
    }

    private BigDecimal somar(List<Movimentacao> movimentacoes, TipoMovimentacao tipo) {
        return movimentacoes.stream()
                .filter(m -> m.getTipo() == tipo)
                .map(Movimentacao::getValor)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
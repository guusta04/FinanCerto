package com.financerto.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class AlertaResponseDTO {

    private Long id;
    private Long usuarioId;
    private String titulo;
    private String mensagem;
    private String tipo;
    private BigDecimal limiteGasto;
    private BigDecimal gastoAtual;
    private LocalDateTime dataCriacao;
    private Boolean lido;

    // Construtores
    public AlertaResponseDTO() {}

    public AlertaResponseDTO(Long id, Long usuarioId, String titulo, String mensagem,
                            String tipo, BigDecimal limiteGasto, BigDecimal gastoAtual,
                            LocalDateTime dataCriacao, Boolean lido) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.titulo = titulo;
        this.mensagem = mensagem;
        this.tipo = tipo;
        this.limiteGasto = limiteGasto;
        this.gastoAtual = gastoAtual;
        this.dataCriacao = dataCriacao;
        this.lido = lido;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getLimiteGasto() {
        return limiteGasto;
    }

    public void setLimiteGasto(BigDecimal limiteGasto) {
        this.limiteGasto = limiteGasto;
    }

    public BigDecimal getGastoAtual() {
        return gastoAtual;
    }

    public void setGastoAtual(BigDecimal gastoAtual) {
        this.gastoAtual = gastoAtual;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public Boolean getLido() {
        return lido;
    }

    public void setLido(Boolean lido) {
        this.lido = lido;
    }
}


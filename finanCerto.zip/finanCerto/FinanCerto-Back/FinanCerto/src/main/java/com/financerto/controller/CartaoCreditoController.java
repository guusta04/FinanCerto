package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.CartaoCreditoRequestDTO;
import com.financerto.dto.CartaoCreditoResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.CartaoCreditoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/cartoes")
public class CartaoCreditoController {

    private final CartaoCreditoService cartaoService;

    public CartaoCreditoController(
            CartaoCreditoService cartaoService) {

        this.cartaoService = cartaoService;
    }

    @PostMapping
    public ResponseEntity<CartaoCreditoResponseDTO> criar(
            @Valid @RequestBody CartaoCreditoRequestDTO dados,
            @AuthenticationPrincipal Usuario usuarioLogado) {

        return ResponseEntity.ok(
                cartaoService.criar(dados, usuarioLogado)
        );
    }

    @GetMapping
    public ResponseEntity<List<CartaoCreditoResponseDTO>> listar(
            @AuthenticationPrincipal Usuario usuarioLogado) {

        return ResponseEntity.ok(
                cartaoService.listar(usuarioLogado)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<CartaoCreditoResponseDTO> buscar(
            @PathVariable Long id,
            @AuthenticationPrincipal Usuario usuarioLogado) {

        return ResponseEntity.ok(
                cartaoService.buscar(id, usuarioLogado)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id,
            @AuthenticationPrincipal Usuario usuarioLogado) {

        cartaoService.excluir(id, usuarioLogado);

        return ResponseEntity.noContent().build();
    }
}

package com.financerto.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.CompraRequestDTO;
import com.financerto.dto.CompraResponseDTO;
import com.financerto.model.Alerta;
import com.financerto.model.CartaoCredito;
import com.financerto.model.Compra;
import com.financerto.model.Fatura;
import com.financerto.model.Notificacao;
import com.financerto.model.Usuario;
import com.financerto.repository.CartaoCreditoRepository;
import com.financerto.repository.CompraRepository;

@Service
public class CompraService {

    private final CompraRepository compraRepository;
    private final CartaoCreditoRepository cartaoRepository;
    private final FaturaService faturaService;
    private final NotificacaoService notificacaoService;
    private final AlertaService alertaService;

    public CompraService(CompraRepository compraRepository,
                          CartaoCreditoRepository cartaoRepository,
                          FaturaService faturaService,
                          NotificacaoService notificacaoService,
                          AlertaService alertaService) {
        this.compraRepository = compraRepository;
        this.cartaoRepository = cartaoRepository;
        this.faturaService = faturaService;
        this.notificacaoService = notificacaoService;
        this.alertaService = alertaService;
    }

    public CompraResponseDTO cadastrar(CompraRequestDTO dados, Usuario usuarioLogado) {
        CartaoCredito cartao = cartaoRepository.findByIdAndUsuarioId(dados.getCartaoId(), usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Cartao nao encontrado"));

        if (cartao.getSaldoDisponivel().compareTo(dados.getValor()) < 0) {
            throw new IllegalArgumentException("Limite disponivel insuficiente para essa compra");
        }

        Compra compra = new Compra(usuarioLogado, cartao, dados.getDescricao(), dados.getValor(), dados.getDataCompra());
        compra.setParcelasTotal(dados.getParcelasTotal());

        compra = compraRepository.save(compra);

        cartao.setSaldoDisponivel(cartao.getSaldoDisponivel().subtract(dados.getValor()));
        cartaoRepository.save(cartao);

        Fatura fatura = faturaService.obterOuCriarFaturaAtual(cartao, dados.getDataCompra());
        faturaService.adicionarValor(fatura, dados.getValor());

        notificacaoService.criar(usuarioLogado, "Compra registrada",
                "Compra de R$ " + dados.getValor() + " em " + cartao.getNomeCartao(),
                Notificacao.TipoNotificacao.COMPRA_REGISTRADA);

        verificarLimiteCartao(cartao, usuarioLogado);

        return toResponseDTO(compra);
    }

    public List<CompraResponseDTO> listar(Usuario usuarioLogado) {
        return compraRepository.findByUsuario(usuarioLogado).stream()
                .map(this::toResponseDTO)
                .toList();
    }

    public void excluir(Long id, Usuario usuarioLogado) {
        Compra compra = compraRepository.findByIdAndUsuarioId(id, usuarioLogado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Compra nao encontrada"));

        CartaoCredito cartao = compra.getCartaoCredito();
        cartao.setSaldoDisponivel(cartao.getSaldoDisponivel().add(compra.getValor()));
        cartaoRepository.save(cartao);

        Fatura fatura = faturaService.obterOuCriarFaturaAtual(cartao, compra.getDataCompra());
        faturaService.removerValor(fatura, compra.getValor());

        compraRepository.delete(compra);
    }

    private void verificarLimiteCartao(CartaoCredito cartao, Usuario usuarioLogado) {
        BigDecimal percentualUso = cartao.getPercentualUso();

        if (percentualUso.compareTo(new BigDecimal("100")) >= 0) {
            alertaService.criar(usuarioLogado, "Limite ultrapassado",
                    "O cartao " + cartao.getNomeCartao() + " ultrapassou o limite disponivel",
                    Alerta.TipoAlerta.LIMITE_ULTRAPASSADO, cartao.getLimiteCartao(), cartao.getSaldoUsado());
        } else if (percentualUso.compareTo(new BigDecimal("80")) >= 0) {
            alertaService.criar(usuarioLogado, "Limite quase atingido",
                    "O cartao " + cartao.getNomeCartao() + " ja usou " + percentualUso + "% do limite",
                    Alerta.TipoAlerta.LIMITE_ATINGIDO, cartao.getLimiteCartao(), cartao.getSaldoUsado());
        }
    }

    private CompraResponseDTO toResponseDTO(Compra compra) {
        return new CompraResponseDTO(
                compra.getId(),
                compra.getUsuario().getId(),
                compra.getCartaoCredito().getId(),
                compra.getDescricao(),
                compra.getValor(),
                compra.getValorParcela(),
                compra.getParcelasTotal(),
                compra.getParcelaAtual(),
                compra.getDataCompra(),
                compra.getDataCriacao(),
                compra.getStatus().name()
        );
    }
}

package com.financerto.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.financerto.dto.CartaoCreditoResponseDTO;
import com.financerto.dto.DashboardResponseDTO;
import com.financerto.dto.MetaFinanceiraResponseDTO;
import com.financerto.model.CartaoCredito;
import com.financerto.model.MetaFinanceira;
import com.financerto.model.Saldo;
import com.financerto.model.Usuario;
import com.financerto.repository.AlertaRepository;
import com.financerto.repository.CartaoCreditoRepository;
import com.financerto.repository.MetaFinanceiraRepository;
import com.financerto.repository.NotificacaoRepository;

@Service
public class DashboardService {

    private final SaldoService saldoService;
    private final MetaFinanceiraRepository metaFinanceiraRepository;
    private final CartaoCreditoRepository cartaoCreditoRepository;
    private final NotificacaoRepository notificacaoRepository;
    private final AlertaRepository alertaRepository;

    public DashboardService(SaldoService saldoService,
                             MetaFinanceiraRepository metaFinanceiraRepository,
                             CartaoCreditoRepository cartaoCreditoRepository,
                             NotificacaoRepository notificacaoRepository,
                             AlertaRepository alertaRepository) {
        this.saldoService = saldoService;
        this.metaFinanceiraRepository = metaFinanceiraRepository;
        this.cartaoCreditoRepository = cartaoCreditoRepository;
        this.notificacaoRepository = notificacaoRepository;
        this.alertaRepository = alertaRepository;
    }

    public DashboardResponseDTO montar(Usuario usuarioLogado) {
        Saldo saldo = saldoService.obterOuCriar(usuarioLogado);

        List<MetaFinanceiraResponseDTO> metasAtivas = metaFinanceiraRepository
                .findByUsuarioAndStatus(usuarioLogado, MetaFinanceira.StatusMetaFinanceira.ATIVA).stream()
                .map(this::toMetaResponseDTO)
                .toList();

        List<CartaoCreditoResponseDTO> cartoesAtivos = cartaoCreditoRepository
                .findByUsuarioAndStatus(usuarioLogado, CartaoCredito.StatusCartao.ATIVO).stream()
                .map(this::toCartaoResponseDTO)
                .toList();

        long notificacoesNaoLidas = notificacaoRepository.countByUsuarioIdAndLida(usuarioLogado.getId(), false);
        long alertasNaoLidos = alertaRepository.countByUsuarioIdAndLido(usuarioLogado.getId(), false);

        return new DashboardResponseDTO(
                saldo.getSaldoAtual(),
                saldo.getTotalReceitas(),
                saldo.getTotalDespesas(),
                notificacoesNaoLidas,
                alertasNaoLidos,
                metasAtivas,
                cartoesAtivos
        );
    }

    private MetaFinanceiraResponseDTO toMetaResponseDTO(MetaFinanceira meta) {
        return new MetaFinanceiraResponseDTO(
                meta.getId(),
                meta.getUsuario().getId(),
                meta.getDescricao(),
                meta.getValorMeta(),
                meta.getValorAtual(),
                meta.getDataMeta(),
                meta.getDataCriacao(),
                meta.getStatus().name(),
                meta.getPercentualProgresso()
        );
    }

    private CartaoCreditoResponseDTO toCartaoResponseDTO(CartaoCredito cartao) {
        return new CartaoCreditoResponseDTO(
                cartao.getId(),
                cartao.getUsuario().getId(),
                cartao.getNumeroCartao(),
                cartao.getNomeCartao(),
                cartao.getLimiteCartao(),
                cartao.getSaldoDisponivel(),
                cartao.getSaldoUsado(),
                cartao.getDataValidade(),
                cartao.getBandeira().name(),
                cartao.getDiaVencimento(),
                cartao.getDataCriacao(),
                cartao.getStatus().name(),
                cartao.getPercentualUso()
        );
    }
}
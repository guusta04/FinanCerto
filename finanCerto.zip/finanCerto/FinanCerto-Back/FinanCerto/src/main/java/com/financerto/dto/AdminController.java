package com.financerto.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.financerto.dto.AlterarRoleRequestDTO;
import com.financerto.dto.PerfilResponseDTO;
import com.financerto.model.Usuario;
import com.financerto.service.UsuarioService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin/usuarios")
public class AdminController {

    private final UsuarioService usuarioService;

    public AdminController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public ResponseEntity<List<PerfilResponseDTO>> listar() {
        return ResponseEntity.ok(usuarioService.listarTodos());
    }

    @PutMapping("/{id}/role")
    public ResponseEntity<PerfilResponseDTO> alterarRole(@PathVariable Long id,
                                                          @Valid @RequestBody AlterarRoleRequestDTO dados) {
        return ResponseEntity.ok(usuarioService.alterarRole(id, dados.getRole()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id,
                                         @AuthenticationPrincipal Usuario usuarioLogado) {
        if (usuarioLogado.getId().equals(id)) {
            throw new IllegalArgumentException("Você não pode excluir seu próprio usuário");
        }

        usuarioService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}